"""Single SDK finalization replay; completed notes are data, never gold or reasoning."""

from __future__ import annotations

import copy
import json
import time

from agents import Agent, RunConfig, Runner

from .contracts import ExplainedAnswer, RepositoryAnswer
from .execution import CancellationToken, HarnessError
from .grounded_schema import GroundedReportSchema
from .runtimes.chat import CompletionResult, fingerprint
from .runtimes.openai_sdk import error_code, sdk_input_budget
from .source_windows import citation_validity


def prepare_replay(row, settings, *, sectioned=False):
    """Change only the output schema of one previously recorded SDK wire request."""
    result = row["result"]
    if result["config"] != settings.public():
        raise ValueError("finalizer replay requires the identical generator configuration")
    decision = result["decisions"][-1]
    if decision.get("phase") != "finalize" or not decision.get("request_sent"):
        raise ValueError("replay requires a dispatched finalizer, not partial research")
    body = copy.deepcopy(decision["request"])
    system = [m for m in body["messages"] if m["role"] == "system"]
    if len(system) != 1 or system[0]["content"] != decision["system_instructions"]:
        raise ValueError("recorded finalizer system message differs from SDK input")
    if sectioned:
        body["response_format"]["json_schema"]["schema"] = ExplainedAnswer.model_json_schema()
    budget = sdk_input_budget(settings, body)
    if not budget["fits"]:
        raise ValueError("replayed finalizer exceeds the unchanged context budget")
    return {"context": copy.deepcopy(result["final_context"]), "input_messages": body["messages"],
            "sdk_input": copy.deepcopy(decision["input"]), "instruction": system[0]["content"], "sectioned": sectioned,
            "expected_request": body, "budget": budget,
            "recorded_row_sha256": fingerprint(row), "recorded_request_sha256": fingerprint(decision["request"]),
            "replay_note": "Completed external notes, source, instruction and generation budget held fixed; output schema is the intervention."}


async def run_replay(runtime, prepared, *, persist=lambda: None):
    """Exactly one typed SDK Runner call. No repair, continuation or model retry."""
    started, token = time.monotonic(), CancellationToken()
    answer, backend = None, None
    completion = CompletionResult(status="failed", request_hash=fingerprint(prepared["expected_request"]))
    try:
        backend = await runtime.verify_backend()
        model = await runtime.open(lambda *_: True, persist, token)
        agent = Agent(name="RepoMentor-format", instructions=prepared["instruction"], model=model,
                      model_settings=runtime.final_model_settings,
                      output_type=GroundedReportSchema(ExplainedAnswer if prepared["sectioned"] else RepositoryAnswer, prepared["context"]))
        result = await Runner.run(agent, prepared["sdk_input"], max_turns=1,
                                  run_config=RunConfig(tracing_disabled=True, trace_include_sensitive_data=False))
        value = result.final_output
        candidate = (value.public_answer() if prepared["sectioned"] else value).model_dump(mode="json")
        if not citation_validity(candidate, prepared["context"]):
            raise HarnessError("invalid_citations", "replayed answer cites unavailable source")
        answer = candidate
        completion.status, completion.content = "success", json.dumps(answer, ensure_ascii=False)
        completion.finish_reason = "stop"
    except Exception as exc:
        code = error_code(exc)
        completion.status = {"truncated": "truncated", "context_limit": "context_limit",
                             "TimeoutError": "timeout", "APITimeoutError": "timeout"}.get(code, "failed")
        completion.error_code = code
    finally:
        await runtime.close()
    sent = [d for d in runtime.calls if d["request_sent"]]
    completion.request_sent = bool(sent)
    completion.elapsed_seconds = round(time.monotonic() - started, 6)
    completion.usage = {name: (sum(d["usage"][name] for d in sent)
        if sent and all(isinstance(d.get("usage", {}).get(name), int) for d in sent) else None)
        for name in ("prompt_tokens", "completion_tokens", "total_tokens")}
    return {"answer": answer, "completion": completion.model_dump(), "decisions": runtime.calls,
            "context": prepared["context"], "final_context": prepared["context"],
            "config_id": runtime.settings.config_id, "backend_verification": backend,
            "new_model_requests": len(sent), "tool_calls": 0,
            "citation_ranges_valid": citation_validity(answer, prepared["context"]),
            "elapsed_seconds": completion.elapsed_seconds, "cache_hit": False,
            "replayed_row_sha256": prepared["recorded_row_sha256"], "sectioned": prepared["sectioned"]}
