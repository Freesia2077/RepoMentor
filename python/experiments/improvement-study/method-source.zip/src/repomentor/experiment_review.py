"""Local, source-checked review import and four-layer experiment summaries; no generation."""

import hashlib
import json
import statistics
from collections import Counter, defaultdict
from pathlib import Path

from .paths import data_root
from .rag_evaluation import coverage, nonblank_reference_complete
from .records import write
from .repository import SnapshotStore
from .runtimes.chat import fingerprint
from .semantic_review import validate_judgment
from .source_windows import citation_validity, verify_spans


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _observed_lines(spans):
    return {(span["path"], number) for span in spans
            for number in range(span["start_line"], span["end_line"] + 1)}


def _diagnose_case(row, task, expected, initial, review):
    """Separate observable evidence gaps and output failures; do not infer semantic causes."""
    cid, result = row["case_id"], row["result"]
    reference = expected.get("sources", [])
    final = result.get("final_context", result["context"])
    observed = result["context"]
    retrieval = (result.get("initial_retrieval") or {}).get("retrieval", result.get("retrieval", {}))
    candidates = [candidate["chunk"] for candidate in retrieval.get("candidates", [])]
    complete = {name: nonblank_reference_complete(reference, spans) for name, spans in
                (("candidates", candidates), ("initial", initial), ("final", final))}
    status = result["completion"]["status"]
    control = row["condition"] in {"none", "closed_book"}
    new_lines = len(_observed_lines(observed) - _observed_lines(initial))
    agent = "tool_trace" in result
    signals = []
    if control:
        signals.append("evidence_control")
    elif task["answerable"]:
        if complete["initial"] is False:
            signals.append("reference_gap_at_input")
            if complete["candidates"] is True:
                signals.append("reference_lost_in_packing")
            if agent and complete["final"] is False and not new_lines:
                signals.append("agent_gap_without_new_source")
        if status == "success" and complete["final"] is True:
            if review["correctness"] in {"incorrect", "partially_correct"}:
                signals.append("reference_complete_fact_error")
            if review["completeness"] in {"partial", "insufficient"}:
                signals.append("reference_complete_incomplete_answer")
    if status != "success":
        signals.append("workflow_failure")
    if review["citation_support"] in {"partial", "unsupported"}:
        signals.append("citation_support_issue")
    if (not task["answerable"] and review["abstention"] == "appropriate"
            and result.get("answer") is not None and result["answer"]["insufficient_evidence"] is False):
        signals.append("abstention_flag_mismatch")
    case = {"case_id": cid, "task_id": row["task_id"], "repository": row["repository"],
        "condition": row["condition"], "cohort": task["cohort"], "answerable": task["answerable"],
        "question": task["input"]["question"], "required_points": expected.get("required_points", []),
        "reference_nonblank_complete": complete, "workflow_status": status,
        "error_code": result["completion"].get("error_code"), "signals": signals,
        "new_observed_source_lines": new_lines, "tool_calls": result.get("tool_calls", 0),
        "model_requests": result["new_model_requests"],
        "review": {k: review[k] for k in ("correctness", "completeness", "citation_support", "abstention", "notes")},
        "review_type": review.get("review_type", "unknown"), "reviewer": review.get("reviewer", "unknown"),
        "research_finalization_attribution": "requires_review" if result.get("research_notes") else "not_recorded",
        "result_sha256": fingerprint(row), "human_approved": False, "training_eligible": False}
    return case


def _diagnosis_markdown(source_batch, cases, groups, limits):
    lines = ["# 保存结果的离线诊断", "", f"来源批次：{source_batch}；{len(cases)} 份回答；新增模型请求 0。", "",
             "复用原模型非盲评审，不重新打分。信号用于定位可观测损失，不能自动认定因果。", "",
             "| 分组 | 回答 | 核心可用 | 完整解决 | 原请求 |", "| --- | ---: | ---: | ---: | ---: |"]
    for key, group in sorted(groups.items()):
        lines.append(f"| {key} | {group['records']} | {group['core_supported']} | {group['fully_resolved']} | {group['model_requests']} |")
    lines += ["", "以下展示前 24 份有诊断信号的记录，全部记录见 cases.json；不是精选成功率。", "",
              "| case_id | 来源 | 信号 |", "| --- | --- | --- |"]
    for case in [case for case in cases if case["signals"]][:24]:
        lines.append(f"| {case['case_id']} | {case['repository']} | {', '.join(case['signals'])} |")
    lines += ["", limits, "", "原批次及其源码评审保持封存；本报告仅验证输入字节和评审绑定，不代替源码语义复核。", ""]
    return "\n".join(lines)


def diagnose_saved(folder, destination):
    """Read sealed evidence and bound reviews; report signals without rescoring or model work."""
    folder, destination = Path(folder).resolve(), Path(destination).resolve()
    if destination == folder or destination.is_relative_to(folder):
        raise ValueError("diagnosis must be outside the sealed source batch")
    if destination.exists():
        raise ValueError("diagnosis destination already exists; choose a new directory")
    manifest = load(folder / "completed-files.json")["sha256"]
    hashes = {}
    for name in ("dataset.json", "results.jsonl", "summary.json"):
        hashes[name] = hashlib.sha256((folder / name).read_bytes()).hexdigest()
        if manifest.get(name) != hashes[name]:
            raise ValueError("sealed source bytes changed: " + name)
    data, saved = load(folder / "dataset.json"), load(folder / "summary.json")
    tasks = {task["task_id"]: task for task in data["tasks"]}
    if any(task.get("split") == "test" for task in tasks.values()):
        raise ValueError("final test set remains sealed")
    rows = [json.loads(line) for line in (folder / "results.jsonl").read_text(encoding="utf-8").splitlines()
            if line.strip()]
    if len({row["case_id"] for row in rows}) != len(rows) or len(rows) != saved["records"]:
        raise ValueError("duplicate or missing saved results")
    cases, groups = [], defaultdict(Counter)
    for row in rows:
        cid, task = row["case_id"], tasks[row["task_id"]]
        review = saved["reviews"].get(cid)
        if review is None or review.get("result_sha256") != fingerprint(row):
            raise ValueError("review is missing or bound to another result: " + cid)
        case = _diagnose_case(row, task, data["evaluation_only"][row["task_id"]],
                              data["prepared_inputs"][cid]["context"], review)
        status = case["workflow_status"]
        cases.append(case)
        group = groups[("answerable/" if task["answerable"] else "unanswerable/") + row["condition"]]
        group.update(records=1, workflow_success=int(status == "success"), model_requests=case["model_requests"],
                     tool_calls=case["tool_calls"])
        group.update("signal/" + signal for signal in case["signals"])
    for key, group in groups.items():
        frozen = saved["groups"][key]
        if frozen["records"] != group["records"]:
            raise ValueError("frozen group count differs from saved records: " + key)
        for metric in ("factually_correct", "core_supported", "fully_resolved"):
            group[metric] = frozen.get(metric, 0)
    limits = ("Signals locate observable losses, not proven causes. Reference coverage is a surrogate; "
              "candidate lists may omit other channels. Research/finalization losses require source-linked review. "
              "Original nonblind reviews are reused, not independent human review; batches must not be pooled.")
    summary = {"schema": "repomentor.saved-diagnosis.v1", "source_batch": folder.name, "records": len(cases),
               "groups": dict(groups), "model_requests": 0, "human_approved": False,
               "training_eligible": False, "limits": limits}
    report = _diagnosis_markdown(folder.name, cases, groups, limits)
    destination.mkdir(parents=True, exist_ok=False)
    write(destination / "cases.json", cases)
    write(destination / "summary.json", summary)
    (destination / "report.md").write_text(report, encoding="utf-8")
    write(destination / "manifest.json", {"source_batch": folder.name, "source_sha256": hashes,
        "source_manifest_sha256": hashlib.sha256((folder / "completed-files.json").read_bytes()).hexdigest(),
        "implementation_sha256": {name: hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest()
                                  for name in ("experiment_review.py", "rag_evaluation.py")},
        "sha256": {name: hashlib.sha256((destination / name).read_bytes()).hexdigest()
                   for name in ("cases.json", "summary.json", "report.md")},
        "human_approved": False, "training_eligible": False})
    return summary


def import_reviews(folder, root):
    candidates = load(folder / "review-candidates.json")
    authored = load(folder / "review-decisions.json")
    judgments = []
    for candidate in candidates:
        key = Path(candidate["source_file"]).stem + "/" + candidate["stage"]
        decision = authored[key]
        value = {"candidate_id": candidate["candidate_id"], **decision}
        source = load(root / candidate["source_file"])
        result = source["result"] if candidate["stage"] == "answer" else next(
            r for r in source["stages"] if r["stage"] == candidate["stage"])
        assert fingerprint(result) == candidate["record_sha256"], "answer changed after review export"
        reader = SnapshotStore(data_root() / "corpus").open(candidate["snapshot_id"])
        checked = validate_judgment(value, {**candidate, "observed_context": candidate["visible_context"]}, reader)
        checked["review_type"] = "nonblind_model_review_same_repository_confirmation" if source.get("split") == "confirmation-development" else "nonblind_model_development_review"
        checked["solved"] = bool(candidate["status"] == "success"
            and checked["correctness"] == "correct" and checked["completeness"] == "adequate"
            and checked["citation_support"] in {"supported", "not_applicable"}
            and checked["abstention"] != "inappropriate" and checked["consistency"] == "consistent")
        judgments.append(checked)
    assert len(authored) == len(candidates), "unused or missing review entries"
    write(folder / "judgments.json", judgments)
    return judgments


def summarize_batch(folder, root):
    candidates = load(folder / "review-candidates.json")
    judgments = {j["candidate_id"]: j for j in load(folder / "judgments.json")} if (folder / "judgments.json").exists() else {}
    experiment = root / "experiments/p63"
    references = {}
    for split in ("development", "confirmation"):
        references.update(load(experiment / "evaluation-only" / (split + ".json")))
    details, groups = [], defaultdict(list)
    for candidate in candidates:
        case = load(root / candidate["source_file"])
        result = case["result"] if candidate["stage"] == "answer" else next(
            s for s in case["stages"] if s["stage"] == candidate["stage"])
        assert fingerprint(result) == candidate["record_sha256"]
        reader = SnapshotStore(data_root() / "corpus").open(candidate["snapshot_id"])
        context = result.get("final_context", result["context"])
        verify_spans(reader, context)
        refs = references.get(case.get("task_id"), {}).get("sources", []) if candidate["stage"] == "answer" else []
        initial = result.get("initial_retrieval") or {}
        raw_candidates = [c["chunk"] for c in initial.get("retrieval", {}).get("candidates", [])]
        trace = result.get("tool_trace", [])
        decisions = [d for d in result.get("decisions", []) if d["request_sent"]]
        calls = decisions or ([result["completion"]] if result["completion"].get("request_sent") else [])
        for call in calls:
            assert call["input_budget"]["fits"] and call["input_budget"]["context_window"] == 8192
        usages = [c.get("usage", {}) for c in calls]
        judgment = judgments.get(candidate["candidate_id"])
        label = (f"{case['repository']}/{candidate['stage']}" if candidate["stage"] != "answer" else
                 f"{case['dialogue_id']}/turn-{case['turn']}" if case.get("dialogue_id") else candidate["task_id"])
        row = {"candidate_id": candidate["candidate_id"], "task_id": label,
            "mode": candidate["mode"], "kind": "report-stage" if candidate["stage"] != "answer" else case.get("kind"), "stage": candidate["stage"],
            "workflow_status": candidate["status"], "solved": judgment["solved"] if judgment else None,
            "citation_ranges_valid": citation_validity(result["answer"], context),
            "reference_candidate_coverage": coverage(refs, raw_candidates),
            "reference_initial_coverage": coverage(refs, initial.get("sources", [])),
            "reference_observed_coverage": coverage(refs, result["context"]),
            "reference_final_coverage": coverage(refs, context),
            "model_requests": len(calls), "new_model_requests": result["new_model_requests"],
            "cache_hit": result["cache_hit"], "elapsed_seconds": result.get("elapsed_seconds", result["completion"]["elapsed_seconds"]),
            "elapsed_scope": "SDK episode after initial retrieval" if result.get("decisions") else "fixed model completion only",
            "prompt_tokens": sum(u.get("prompt_tokens") or 0 for u in usages),
            "completion_tokens": sum(u.get("completion_tokens") or 0 for u in usages),
            "invalid_tool_calls": sum(s["observation"]["status"] == "error" for s in trace),
            "duplicate_tool_calls": sum(s["observation"].get("error_code") == "duplicate_action" for s in trace),
            "context_compactions": sum(bool(e.get("compacted")) for e in result.get("local_trace", [])),
            "stop_reason": result.get("stop_reason", result["completion"].get("error_code")),
            "initial_source_sha256": fingerprint(initial.get("sources", []))}
        details.append(row)
        groups[row["mode"]].append(row)
    summary = {}
    blocked = defaultdict(list)
    for path in sorted((folder / "cases").glob("*.json")):
        case = load(path)
        if case.get("result") is None and not case.get("stages"):
            blocked[case.get("mode", "sdk")].append({"case": path.stem, "reason": case.get("blocked_by")})
        elif case.get("stages"):
            attempted = {stage["stage"] for stage in case["stages"]}
            for stage in ("explorer", "mentor", "contributor"):
                if stage not in attempted:
                    blocked["sdk"].append({"case": path.stem + "/" + stage, "reason": "previous_failed_stage"})
    for mode, rows in groups.items():
        summary[mode] = {"cases": len(rows), "solved": sum(r["solved"] is True for r in rows),
            "scheduled_cases": len(rows) + len(blocked[mode]), "blocked_cases": blocked[mode],
            "reviewed": sum(r["solved"] is not None for r in rows),
            "statuses": dict(Counter(r["workflow_status"] for r in rows)),
            "mean_model_requests": statistics.mean(r["model_requests"] for r in rows),
            **{k: sum(r[k] for r in rows) for k in ("model_requests", "new_model_requests", "prompt_tokens", "completion_tokens", "elapsed_seconds", "invalid_tool_calls", "duplicate_tool_calls")}}
    paired = []
    for task_id in sorted({r["task_id"] for r in details if r["task_id"]}):
        pair = {r["mode"]: r for r in details if r["task_id"] == task_id}
        if {"fixed", "sdk"} <= pair.keys():
            equal = pair["fixed"]["initial_source_sha256"] == pair["sdk"]["initial_source_sha256"]
            paired.append({"task_id": task_id, "kind": pair["sdk"]["kind"], "initial_retrieval_equal": equal,
                           "fixed_solved": pair["fixed"]["solved"], "sdk_solved": pair["sdk"]["solved"]})
    gains = sum(r["kind"] in {"cross_function", "multi_file"} and r["sdk_solved"] is True and r["fixed_solved"] is False for r in paired)
    losses = sum(r["kind"] in {"cross_function", "multi_file"} and r["sdk_solved"] is False and r["fixed_solved"] is True for r in paired)
    result = {"modes": summary, "details": details, "pairs": paired,
        "cross_function_extra_solved": gains, "cross_function_regressions": losses,
        "cross_function_net_gain": gains - losses, "reviewer": "Codex", "blind": False,
        "human_approved": False, "training_eligible": False,
        "limits": "Reference range coverage is diagnostic and may omit alternative valid evidence. Semantic verdicts are authored separately; workflow success is not correctness. Latencies exclude initial retrieval: fixed completion vs SDK episode; these are not end-to-end wall times."}
    write(folder / "comparison.json", result)
    lines = ["# P6.3 对照评测", "", "Codex 非盲模型评审；同仓库题目，不是官方榜单或人工签核。", "",
             "| 条件 | 已评审 / 总数 | 解决 | 平均请求 | 输入 / 输出 token | 已记录阶段耗时（秒） |", "| --- | --- | --- | --- | --- | --- |"]
    for mode, r in summary.items():
        lines.append(f"| {mode} | {r['reviewed']} / {r['scheduled_cases']} | {r['solved']} | {r['mean_model_requests']:.2f} | {r['prompt_tokens']} / {r['completion_tokens']} | {r['elapsed_seconds']:.1f} |")
    if any(blocked.values()):
        lines += ["", "阻塞轮次计入计划题数和未解决数；平均请求数仅针对实际运行的轮次。"]
    lines += ["", "耗时口径：固定 RAG 为模型完成耗时，SDK 为初始检索之后的运行耗时；均不包含索引/初始检索，不作为端到端速度对比。检索冷缓存与热查询另表报告。"]
    lines += ["", f"跨函数/多文件新增解决 {gains} 题、退步 {losses} 题、净增 {gains-losses} 题。", "",
              "## 逐题与过程归因", "", "| 题目 | 条件 | 工作流 | 解决 | 候选 / 已读 / 最终参考覆盖 | 请求 |", "| --- | --- | --- | --- | --- | --- |"]
    for r in details:
        lines.append(f"| {r['task_id']} | {r['mode']} | {r['workflow_status']} | {r['solved']} | {r['reference_candidate_coverage']} / {r['reference_observed_coverage']} / {r['reference_final_coverage']} | {r['model_requests']} |")
    (folder / "comparison.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return result
