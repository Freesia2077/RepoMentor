"""Offline operation rehearsal and anonymous review of frozen benchmark records."""

import argparse
import hashlib
import json
import random
import secrets
import socket
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter

from repomentor.paths import data_root
from repomentor.records import write
from repomentor.repository import SnapshotStore, git
from repomentor.semantic_review import RUBRIC, candidate_digest, quality_tiers, validate_judgment

ROOT = Path(__file__).resolve().parents[1]
DEFAULT = ROOT / "experiments/improvement-pilot"
PRIVATE = ROOT / "artifacts/improvement-pilot"


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def relative(path):
    return Path(path).resolve().relative_to(ROOT).as_posix()


def freeze(path, value):
    path = Path(path)
    if path.exists():
        raise ValueError(f"refusing to replace frozen file: {relative(path)}")
    write(path, value)


def reader_for(task):
    reader = SnapshotStore(data_root() / "corpus").open(task["snapshot_id"])
    if reader.snapshot.commit_sha != task["commit_sha"]:
        raise ValueError("snapshot commit differs from task")
    return reader


def excerpt(reader, source):
    text, truncated = reader.read(source["path"], 2_000_000)
    start, end = source["start_line"], source["end_line"]
    lines = text.splitlines()
    if truncated or not 1 <= start <= end <= len(lines):
        raise ValueError("source window outside fixed snapshot")
    content = "\n".join(lines[start - 1:end])
    return {**source, "content": content, "content_sha256": hashlib.sha256(content.encode()).hexdigest()}


def suite_data(suite):
    dataset = load(suite / "dataset.json")
    rows = [json.loads(line) for line in (suite / "results.jsonl").read_text(encoding="utf-8").splitlines()]
    tasks = {t["task_id"]: t for t in dataset["tasks"]}
    if len({r["case_id"] for r in rows}) != len(rows):
        raise ValueError("duplicate result identity")
    if any(tasks[r["task_id"]]["split"] == "test" for r in rows):
        raise ValueError("reserved final-test tasks are not a pilot or review source")
    return dataset, tasks, rows


def packet(suite, output):
    dataset, tasks, rows = suite_data(suite)
    if output.exists():
        raise ValueError("packet destination must be new")
    packet_id = secrets.token_hex(12)
    identities, candidates = {}, []
    for row in rows:
        task, result = tasks[row["task_id"]], row["result"]
        cid = "candidate-" + secrets.token_hex(8)
        refs = dataset.get("evaluation_only", {}).get(row["task_id"], {})
        candidates.append({"candidate_id": cid, "question": task["input"]["question"],
            "history": task["input"].get("history", []), "history_provenance": task.get("history_provenance"),
            "snapshot_id": task["snapshot_id"], "commit_sha": task["commit_sha"],
            "answer": result.get("answer"), "observed_context": result.get("final_context", result.get("context", [])),
            "completion_status": result["completion"]["status"],
            "required_points": refs.get("required_points", refs.get("key_points", [])),
            "scoring_boundaries": refs.get("scoring_boundaries"),
            "evaluation_sources": [excerpt(reader_for(task), s) for s in refs.get("sources", [])]})
        identities[cid] = {"case_id": row["case_id"], "task_id": row["task_id"],
            "record_sha256": candidate_digest(row), "condition": row.get("condition")}
    random.SystemRandom().shuffle(candidates)
    freeze(output / "packet.json", candidates)
    freeze(output / "rubric.json", RUBRIC)
    lines = ["# Anonymous source review", "", "Condition labels and execution settings are withheld.",
        "Score correctness, coverage and citation support separately; preserve workflow failures.", ""]
    for c in candidates:
        lines += [f"## {c['candidate_id']}", ""]
        if c["history"]:
            lines += ["Fixed task history:", "```json", json.dumps(c["history"], ensure_ascii=False, indent=2),
                      "```", str(c["history_provenance"]), ""]
        lines += [c["question"], "", "```json",
                  json.dumps(c["answer"], ensure_ascii=False, indent=2), "```", "", "Actual visible sources:", ""]
        for s in c["observed_context"]:
            lines += [f"{s['path']}:{s['start_line']}-{s['end_line']}", "```", s["content"], "```", ""]
        lines += ["Review-only necessary points:", *[f"- {p}" for p in c["required_points"]], ""]
        if c["scoring_boundaries"]:
            lines += ["Review-only scoring boundary:", c["scoring_boundaries"], ""]
        for s in c["evaluation_sources"]:
            lines += [f"Review-only {s['path']}:{s['start_line']}-{s['end_line']}", "```", s["content"], "```", ""]
    (output / "packet.md").write_text("\n".join(lines), encoding="utf-8")
    freeze(output / "manifest.json", {"schema": "repomentor.anonymous-source-review.v1", "packet_id": packet_id,
        "source_suite": relative(suite), "source_sha256": {name: digest(suite / name)
            for name in ("dataset.json", "results.jsonl")},
        "record_sha256": sorted(candidate_digest(row) for row in rows),
        "output_sha256": {name: digest(output / name) for name in ("packet.json", "packet.md", "rubric.json")},
        "records": len(rows), "human_participants": 0, "human_approved": False,
        "independent_human_review_completed": False, "training_eligible": False,
        "blinding_limit": "Identity removal does not hide stylistic cues or a reviewer's prior knowledge."})
    freeze(PRIVATE / f"{packet_id}-identities.json", identities)
    print(json.dumps({"packet": relative(output), "records": len(rows), "packet_id": packet_id}))


def import_review(output, decisions, origin):
    manifest = load(output / "manifest.json")
    suite = ROOT / manifest["source_suite"]
    for name, sha in manifest["source_sha256"].items():
        if digest(suite / name) != sha:
            raise ValueError("source suite changed after anonymization")
    for name, sha in manifest["output_sha256"].items():
        if digest(output / name) != sha:
            raise ValueError("review packet changed")
    _, tasks, rows = suite_data(suite)
    records = {r["case_id"]: r for r in rows}
    identities = load(PRIVATE / f"{manifest['packet_id']}-identities.json")
    candidates = {c["candidate_id"]: c for c in load(output / "packet.json")}
    values = load(decisions)
    if len({v["candidate_id"] for v in values}) != len(values):
        raise ValueError("duplicate review identity")
    validated = []
    for value in values:
        cid = value["candidate_id"]
        identity = identities[cid]
        if candidate_digest(records[identity["case_id"]]) != identity["record_sha256"]:
            raise ValueError("review source record changed")
        judged = validate_judgment(value, candidates[cid], reader_for(tasks[identity["task_id"]]))
        validated.append({**judged, "tiers": quality_tiers(judged, candidates[cid]["completion_status"])})
    freeze(output / "validated-judgments.json", validated)
    freeze(output / "review-receipt.json", {"packet_sha256": digest(output / "packet.json"),
        "decisions_sha256": digest(decisions), "validated_sha256": digest(output / "validated-judgments.json"),
        "reviewed": len(validated), "planned": len(candidates), "human_participants": 0,
        "human_approved": False, "training_eligible": False,
        "review_origin": origin, "new_quality_judgments": origin != "historical-review-replay",
        "review_type": "model_assisted_source_review; independence depends on reviewer context"})
    print(json.dumps({"reviewed": len(validated), "planned": len(candidates)}))


def rehearse(output):
    if output.exists():
        raise ValueError("simulation destination must be new")
    _, tasks, rows = suite_data(ROOT / "experiments/rag-system")
    saved = {r["case_id"]: r for r in rows}
    mitt = tasks["q-35441446c0f3e154"]
    nanoid = tasks["q-b73aeb622c828d8e"]
    turns = [load(ROOT / f"experiments/p63-closeout/demo-cpu/cases/turn-{i}.json") for i in range(1, 5)]
    plans = [
        {"workflow": "behavior_and_explicit_parameters", "task": nanoid, "terms": ["customAlphabet"],
         "windows": [{"path": "non-secure/index.js", "start_line": 5, "end_line": 17}],
         "saved": [saved["q-b73aeb622c828d8e--bm25_code"]],
         "finding": "Saved BM25 answer incorrectly uses 21; explicit defaultSize=2.9 yields lengths 2,0,0."},
        {"workflow": "implementation_and_test_assertion", "task": mitt,
         "terms": ["on<Key", "should NOT normalize case"],
         "windows": [{"path": "src/index.ts", "start_line": 66, "end_line": 73},
                     {"path": "test/index_test.ts", "start_line": 79, "end_line": 90}],
         "saved": [saved["q-35441446c0f3e154--bm25_code"], next(r for r in suite_data(
             ROOT / "experiments/rag-consolidation")[2] if r["case_id"] == "q-35441446c0f3e154--agentic")],
         "finding": "Saved BM25 explains FOO/foo and Bar/bar assertions; SDK final omits these concrete checks."},
        {"workflow": "followup_changes_current_target", "task": mitt,
         "terms": ["on<Key", "should NOT normalize case", "off<Key", "emit<Key"],
         "windows": [{"path": "src/index.ts", "start_line": 66, "end_line": 73},
                     {"path": "test/index_test.ts", "start_line": 79, "end_line": 90},
                     {"path": "src/index.ts", "start_line": 82, "end_line": 91},
                     {"path": "src/index.ts", "start_line": 103, "end_line": 121}], "saved": turns,
         "finding": "Four saved turns exist, but turn 2 cites types rather than the case assertion; turn 3 says delete although source sets an empty array."},
    ]
    for plan in plans:
        for row in plan["saved"]:
            path = output / "saved-records" / (candidate_digest(row) + ".json")
            if not path.exists():
                freeze(path, row)
    runs = []
    for index, plan in enumerate(plans):
        route_order = ["literal_search_read", "saved_assistant_read"]
        if index % 2:
            route_order.reverse()
        for route in route_order:
            start = perf_counter()
            reader = reader_for(plan["task"])
            actions = []
            if route == "literal_search_read":
                for term in plan["terms"]:
                    began = perf_counter()
                    found = git("--git-dir", str(reader.bare), "grep", "-n", "-I", "-F", "-e", term,
                                reader.snapshot.commit_sha, "--").decode("utf-8")
                    actions.append({"action": "git_literal_search", "query": term,
                        "elapsed_seconds": perf_counter() - began, "matches": len(found.splitlines()),
                        "output_sha256": hashlib.sha256(found.encode()).hexdigest(),
                        "visible_hits": found.splitlines()[:30]})
                windows = plan["windows"]
            else:
                windows = []
                for row in plan["saved"]:
                    began = perf_counter()
                    saved_path = output / "saved-records" / (candidate_digest(row) + ".json")
                    result = load(saved_path)["result"]
                    actions.append({"action": "saved_answer_read", "question": result["question"],
                        "record_sha256": candidate_digest(row), "answer": result.get("answer"),
                        "original_completion_status": result["completion"]["status"],
                        "elapsed_seconds": perf_counter() - began, "serialized_bytes": saved_path.stat().st_size})
                    if result.get("answer"):
                        windows.extend(result["answer"].get("citations", []))
            for window in windows:
                began = perf_counter()
                source = excerpt(reader, window)
                actions.append({"action": "read_fixed_source", "source": source,
                                "elapsed_seconds": perf_counter() - began})
            runs.append({"workflow": plan["workflow"], "route": route, "route_order": route_order,
                "snapshot_id": reader.snapshot.snapshot_id, "commit_sha": reader.snapshot.commit_sha,
                "elapsed_seconds": perf_counter() - start, "actions": actions,
                "semantic_observation": plan["finding"], "task_success_automatically_inferred": False})
    freeze(output / "runs.json", runs)
    freeze(output / "protocol.json", {"operator": "agent simulation", "human_participants": 0,
        "real_user_study": False, "generation_requests": 0, "target_code_executed": False,
        "timing": "perf_counter around immutable source operations and reading per-record saved JSON; no model wait or human reading time",
        "cache": "fresh SnapshotReader per route; Git and OS caches uncontrolled; route order alternates",
        "selection": "known developer-selected tasks and source windows; no learning-effect or causal control",
        "human_approved": False, "training_eligible": False,
        "recorded_at": datetime.now(timezone.utc).isoformat()})
    source_files = ["experiments/rag-system/dataset.json", "experiments/rag-system/results.jsonl",
        "experiments/rag-consolidation/dataset.json", "experiments/rag-consolidation/results.jsonl",
        *[f"experiments/p63-closeout/demo-cpu/cases/turn-{i}.json" for i in range(1, 5)]]
    freeze(output / "manifest.json", {"schema": "repomentor.operation-rehearsal.v1",
        "source_sha256": {p: digest(ROOT / p) for p in source_files},
        "output_sha256": {p.relative_to(output).as_posix(): digest(p)
                          for p in output.rglob("*") if p.is_file()},
        "runner_sha256": digest(__file__), "human_participants": 0,
        "human_approved": False, "training_eligible": False})
    print(json.dumps({"runs": len(runs), "workflows": len(plans), "generation_requests": 0,
                      "source_reads": sum(a["action"] == "read_fixed_source" for r in runs for a in r["actions"])}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("simulate", "packet", "import-review"))
    parser.add_argument("--suite", type=Path)
    parser.add_argument("--output", type=Path, default=DEFAULT / "simulation")
    parser.add_argument("--decisions", type=Path)
    parser.add_argument("--review-origin", choices=("new-model-assisted", "historical-review-replay"),
                        default="new-model-assisted")
    args = parser.parse_args()

    def deny_network(*_args, **_kwargs):
        raise RuntimeError("pilot and review commands are offline")

    socket.socket.connect = deny_network
    socket.socket.connect_ex = deny_network
    if args.action == "simulate":
        rehearse(args.output)
    elif args.action == "packet":
        packet(args.suite, args.output)
    else:
        import_review(args.output, args.decisions, args.review_origin)


if __name__ == "__main__":
    main()
