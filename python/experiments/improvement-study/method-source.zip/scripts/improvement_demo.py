"""Export three curated interview cases offline; never load settings or run a model."""

import argparse
import hashlib
import json
import socket
from pathlib import Path
from unittest.mock import patch

from repomentor.presentation import render_run

ROOT = Path(__file__).resolve().parents[1]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def export(output):
    output = output.resolve()
    if output.exists():
        raise ValueError("Choose a new output directory; existing demonstrations are preserved.")
    inputs = {}

    def frozen(batch, name):
        base = ROOT / "experiments" / batch
        manifest = base / "completed-files.json"
        path = base / name
        expected = json.loads(manifest.read_text(encoding="utf-8"))["sha256"][name]
        if digest(path) != expected:
            raise ValueError(f"Frozen input changed: {batch}/{name}")
        inputs[str(manifest.relative_to(ROOT))] = digest(manifest)
        inputs[str(path.relative_to(ROOT))] = expected
        return path

    def rows(batch):
        return {r["case_id"]: r for r in (
            json.loads(line) for line in frozen(batch, "results.jsonl").read_text(encoding="utf-8").splitlines()
        )}

    system = rows("rag-system")
    consolidation = rows("rag-consolidation")
    summary = json.loads(frozen("rag-system", "summary.json").read_text(encoding="utf-8"))
    records = {
        "mitt-bm25": system["q-35441446c0f3e154--bm25"],
        "mitt-code-aware": system["q-35441446c0f3e154--bm25_code"],
        "mitt-followup-before": json.loads(frozen(
            "qwen9b-reliability", "dialogue/cases/mitt-turn-2.json").read_text(encoding="utf-8")),
        "mitt-followup-after": json.loads(frozen(
            "qwen9b-followup", "cases/mitt-turn-2.json").read_text(encoding="utf-8")),
        "chalk-redundant-read": consolidation["q-4cfe308994156f5d--agentic"],
        "cachetools-missing-read": consolidation["q-71b59398a21ab6c3--agentic"],
    }
    pages = {
        "01-retrieval.md": (
            "# 代码证据交付的配对变化\n\n同一已知题、一次固定回答；不是 Agent 工具收益。\n\n"
            "普通 BM25 引用测试但只给结论，初始实现仅 src/index.ts:2–4；增强条件交付实现"
            "46–105 和具体断言，回答补齐原始 Map 键与大小写测试。\n\n",
            ("mitt-bm25", "mitt-code-aware"),
        ),
        "02-followup.md": (
            "# 多轮目标传递修复\n\n当前问题明确问 off，旧最终回答却解释 on。修复将当前 question"
            "与 resolved_query 导航字段分开，回答恢复为清空数组并保留 Map 键。\n\n"
            "这是已知失败开发回归；该四轮会话严格解决 1/4 → 2/4，不是新确认。\n\n",
            ("mitt-followup-before", "mitt-followup-after"),
        ),
        "03-investigation-failure.md": (
            "# 工具可执行与有效补查的差别\n\nChalk 重读当前已可见的 172–198 行，返回 already_read，"
            "新增源码为零；最终仍把单参数 null 转换误读为空字符串，源码实际是 'null'。\n\n"
            "cachetools 初始缺实际 _wrapper/_unlocked，工具调用为零，答案混入错误分支和统计字段。"
            "前者是充分源码下的理解错误，后者包含未补查证据缺口。两者不能靠工具调用率合并解释。\n\n",
            ("chalk-redundant-read", "cachetools-missing-read"),
        ),
    }
    files = {}
    for name, (intro, keys) in pages.items():
        sections = [intro]
        for key in keys:
            sections.extend([f"## {key}\n\n原记录导出：[JSON](records/{key}.json)。\n\n", render_run(records[key])])
        files[name] = "\n\n".join(sections)
    table = ["| 条件 | 核心可用 / 42 | 完整解决 / 42 | 模型请求 |", "| --- | ---: | ---: | ---: |"]
    for condition in ("bm25", "bm25_code", "hybrid_rerank", "agentic"):
        group = summary["groups"]["answerable/" + condition]
        table.append(f"| {condition} | {group['core_supported']} | {group['fully_resolved']} | {group['model_requests']} |")
    files["index.md"] = (
        "# RepoMentor 离线面试演示\n\n仅导出保存结果，不加载配置、模型、索引或仓库缓存。"
        "网络连接在导出期间被阻断，新增模型请求为 0。\n\n"
        "按顺序打开：[检索配对](01-retrieval.md)、[多轮修复](02-followup.md)、"
        "[补查失败](03-investigation-failure.md)。总时长 5–8 分钟，讲解稿见 notes/interview-playbook.md。\n\n"
        + "\n".join(table)
        + "\n\n表格只来自历史 rag-system 同 42 道源码题；另 6 道私有数据题单列。"
        "这是已知题非盲开发评审，不是当前版本或独立用户收益。最新验证单独查阅系统卡。\n"
    )
    files.update({f"records/{key}.json": json.dumps(value, ensure_ascii=False, indent=2) + "\n"
                  for key, value in records.items()})
    output.mkdir(parents=True)
    for name, content in files.items():
        path = output / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
    receipt = {"schema": "repomentor.interview-demo.v1", "inputs_sha256": inputs,
               "sha256": {name: digest(output / name) for name in files},
               "model_requests": 0, "network_connections_blocked": True,
               "semantic_review": "reuses frozen cases; no new correctness claims"}
    (output / "manifest.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return {"output": str(output), "files": len(files) + 1, "model_requests": 0}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "artifacts" / "interview-demo")
    args = parser.parse_args()
    with patch.object(socket.socket, "connect", side_effect=RuntimeError("Offline export: network blocked")), \
            patch.object(socket.socket, "connect_ex", side_effect=RuntimeError("Offline export: network blocked")):
        print(json.dumps(export(args.output), ensure_ascii=False))


if __name__ == "__main__":
    main()
