"""Freeze ten source-reviewed, non-training questions without any model calls."""

import argparse
import hashlib
import json
import re
from collections import Counter, defaultdict
from pathlib import Path

from repomentor.paths import data_root, python_home
from repomentor.question_bank import digest, normalized, question_id
from repomentor.repository import SnapshotStore, is_source
from repomentor.source_windows import source_span

ROOT = python_home()
OUT = ROOT / "experiments/improvement-confirmation-design"
REPOSITORIES = (
    {"repository": "pallets-eco/blinker", "snapshot_id": "ea71d9f40489ee1fe7005dd1",
     "commit_sha": "c3364059663df1ddce32799d6b1922af89a345f6", "license_spdx": "MIT",
     "license_path": "LICENSE.txt", "license_sha256": "9eb73a1f38597a4aa17025d2ae1be3839624c795e985d4f0e9769ce29faca467"},
    {"repository": "jd/tenacity", "snapshot_id": "bcb069b93214c1a0a2f7e705",
     "commit_sha": "32ac68f0941319c0d2f4fb927f96e4ee29bb46c6", "license_spdx": "Apache-2.0",
     "license_path": "LICENSE", "license_sha256": "58d1e17ffe5109a7ae296caafcadfdbe6a7d176f0bc4ab01e12a689b0499d8bd"},
)


def specs():
    """Questions are ordinary API usage scenarios; reference points stay evaluator-only."""
    return {
        "pallets-eco/blinker": [
            {"question": "我在初始化函数里定义了一个局部回调，用 Blinker 的 sig.connect(callback) 注册后就返回，之后也没有保存回调对象。稍后发送信号却没收到事件，库会一直强引用这个回调吗？应怎样改注册方式？请给出实现及能验证差异的测试位置。",
             "workflow": "behavior-and-tests", "points": ["connect 默认 weak=True，以弱引用保存接收器，回调被回收后自动断开，而非始终强引用。", "没有其他强引用时，局部回调可随作用域结束被回收；用 weak=False 或由业务保留强引用可避免。", "定位弱引用和强引用两种测试，说明删除局部引用、收集后 send 的不同断言。"],
             "refs": [("src/blinker/base.py", 91, 118), ("src/blinker/base.py", 399, 413), ("tests/test_signals.py", 219, 257)],
             "boundaries": "无需声称各 Python 实现的精确回收时刻；不把作用域结束必定立刻回收当硬要求。测试可用其他语义等价行段。"},
            {"question": "我把同一个 Blinker 回调既注册到所有发送者，又注册到发送者 123。sig.send(123) 会调用它两次吗？请解释去重机制，并指出仓库里验证这一情况的测试和关键断言。",
             "workflow": "behavior-and-tests", "points": ["对同一个接收器，send(123) 只调用一次，不因 ANY 和具体发送者重复。", "connect 以接收器标识保存到集合；receivers_for 合并 ANY 与具体 sender 的接收器 ID 集合，send 遍历该集合。", "test_no_double_send 中 send(123) 后 sentinel == [None,123]，而非重复 123；准确说明这个断言。"],
             "refs": [("src/blinker/base.py", 107, 118), ("src/blinker/base.py", 242, 253), ("src/blinker/base.py", 326, 362), ("tests/test_signals.py", 397, 414)],
             "boundaries": "不要求展开 make_id 的所有类型分支，也不要求断言回调执行顺序稳定。"},
            {"question": "为了测试，我只在 with sig.connected_to(receiver) 块内临时订阅事件。如果块中抛出的不是普通 Exception，而是自定义 BaseException，离开后 receiver 还会留在信号上吗？请用清理实现和对应测试说明。",
             "workflow": "behavior-and-tests", "points": ["正常退出、Exception 或 BaseException 都经过 finally 断开临时接收器；没有本题以外的预存连接时，退出后不再留在信号上。", "connected_to 在进入时 weak=False 连接，yield 置于 try/finally，finally 调 disconnect。", "tests/test_context.py 对 Failure(Exception) 与 BaseFailure(BaseException) 参数化，异常路径最终断言 not sig.receivers；不能把未执行的 send(3) 当作执行过的证据。"],
             "refs": [("src/blinker/base.py", 167, 189), ("tests/test_context.py", 43, 68)],
             "boundaries": "场景假定 receiver 原先未连接；无需评判对已有多发送者连接的恢复行为。"},
            {"question": "现在改成同步函数和 async def 接收器混用：直接 sig.send() 会自动 await 异步回调吗？如果改成 await sig.send_async()，还需要怎样适配同步回调？请按两个入口的实际条件解释。",
             "workflow": "fixed-followup-condition-switch",
             "history": [{"role": "user", "content": "我在 Blinker 里注册的事件接收器原来全是普通同步函数，想从同步代码发送信号。"}, {"role": "assistant", "content": "我会按同步接收器这个条件检查；请继续描述你现在要确认的调用方式。"}],
             "query": "Blinker 同步和 async def 接收器混用 sig.send sig.send_async 适配条件",
             "points": ["同步 send 发现 coroutine function 且未传 _async_wrapper 时抛 RuntimeError，不会自动 await；传 wrapper 后同步调用 wrapper(receiver)。", "send_async 对异步接收器直接 await，但对普通同步接收器若没有 _sync_wrapper 同样抛 RuntimeError。", "给 send_async 提供将同步函数转为 awaitable 的 _sync_wrapper；回答必须以当前混用条件为准，不沿用历史全同步假设。"],
             "refs": [("src/blinker/base.py", 237, 253), ("src/blinker/base.py", 287, 303), ("tests/test_signals.py", 260, 283)],
             "boundaries": "无需给可直接运行的线程或事件循环完整代码；不能声称库自动选择事件循环或并行执行所有接收器。"},
            {"question": "只看这份 Blinker 仓库源码，请告诉我公司生产环境过去 24 小时总共发送了多少次订单信号，以及最慢一次回调耗时多少毫秒。没有给你日志、埋点或进程访问。",
             "workflow": "private-runtime-information", "points": ["不能从仓库静态源码确定公司私有运行次数或最慢耗时，不编造数字。", "明确需要生产日志、埋点或遥测等外部运行数据，并设置 insufficient_evidence=true。"], "refs": [],
             "boundaries": "拒答本身不要求源码引文；主动补充的代码事实仍须由实际可见源码支持，不以泛泛介绍替代边界。"},
        ],
        "jd/tenacity": [
            {"question": "我用 Tenacity 给同步网络调用重试，配置 stop_after_delay(10)，每次失败后等 3 秒。假定上一次失败时已耗时 9 秒，这能保证不再睡到第 12 秒吗？如果要求把下一次等待也算进去，应该用什么停止策略？请说明等待计算与停止判断的调用顺序。",
             "workflow": "cross-file-condition",
             "points": ["stop_after_delay 只比较 seconds_since_start >=10；9 秒时为 False，仍可睡 3 秒并开始下一次尝试，不能保证总耗时不超 10 秒。", "stop_before_delay 把 seconds_since_start+upcoming_sleep 与阈值比较；9+3>=10 为 True，拒绝该次等待/下一次尝试。", "重试路径在 _run_wait 计算 upcoming_sleep 后再 _run_stop；停止才决定不进入 DoSleep。不声称该策略能抢占或中断一次已开始的网络调用。"],
             "refs": [("tenacity/stop.py", 100, 138), ("tenacity/__init__.py", 429, 434), ("tenacity/__init__.py", 460, 500)],
             "boundaries": "任务假定失败符合 retry 策略；无需计算首次执行耗时或绝对钟精度；严格停止不等于硬实时取消。"},
            {"question": "我把 Tenacity 的 after 回调用于统计每次调用完成。默认异常重试策略下，函数第一次就成功返回时也会执行 after 吗？若前两次抛异常、第三次成功，after 会记录到第几次？请指出控制分支及仓库测试能说明的边界。",
             "workflow": "behavior-and-tests", "points": ["默认异常策略下首次成功不需要重试，直接取 outcome.result，跳过 after。", "前两次满足异常重试才调用 after；第三次成功跳过，最后记录 attempt_number==2，而非3。", "tests/test_tenacity.py 的 test_after_attempts 在前两次异常、第三次成功后断言记录数为2；after 不是通用的每次完成钩子。"],
             "refs": [("tenacity/__init__.py", 259, 279), ("tenacity/__init__.py", 443, 470), ("tenacity/retry.py", 88, 105), ("tests/test_tenacity.py", 1853, 1870)],
             "boundaries": "限定默认异常重试，不要求 after 对自定义 result-retry 的行为；不得把所有成功返回都概括为永不调用 after。"},
            {"question": "我的同步函数连续三次都抛 ValueError，用 Tenacity 设置 stop_after_attempt(3)、reraise=True，同时给 retry_error_callback 传一个返回字符串 'fallback' 的函数。达到停止条件时会先重新抛出 ValueError，还是把 'fallback' 返回给调用者？请解释两项配置的优先关系。",
             "workflow": "configuration-priority", "points": ["到停止条件时先检查 retry_error_callback，存在可调用且真值的回调则安排并返回回调结果，本例返回 'fallback'。", "该分支提前 return，不进入构造 RetryError 和依据 reraise 重抛的 exc_check 分支，因此本例不会因 reraise=True 强制重抛 ValueError。", "回调返回值经 iter 的最后一个 action 结果返回，再由同步 Retrying.__call__ 返回给调用方；不混淆返回一个 Future 与对 Future 调 result。"],
             "refs": [("tenacity/__init__.py", 436, 441), ("tenacity/__init__.py", 472, 486), ("tenacity/__init__.py", 548, 562)],
             "boundaries": "假定 callback 自身正常返回指定字符串；无需探讨 callback 抛错或非函数假值对象。"},
            {"question": "现在我只对某一次调用改用 wrapped.retry_with(enabled=False)，原装饰器仍是 stop_after_attempt(3)、reraise=False。函数一进来就抛 ValueError：这次还会执行三次，或把异常包装成 RetryError 吗？这个改动会永久改掉原 wrapped 的重试设置吗？",
             "workflow": "fixed-followup-condition-switch",
             "history": [{"role": "user", "content": "我给一个同步函数加了 Tenacity 的 @retry(stop=stop_after_attempt(3), reraise=False)，正在排查失败时的行为。"}, {"role": "assistant", "content": "我会先按启用重试的装饰器配置理解；你可以继续给出要变更的单次调用条件。"}],
             "query": "Tenacity wrapped.retry_with(enabled=False) 单次调用 ValueError 原始装饰器 重试设置 copy",
             "points": ["enabled=False 的同步调用直接执行原函数一次，原始 ValueError 传播，不执行三次，也不包装 RetryError；reraise=False 在此绕过重试路径不生效。", "retry_with 用 self.copy 生成新的 retry 对象再 wraps，构造改过配置的独立包装；不永久修改原 wrapped 的策略。", "当前问题的 disabled 条件优先于历史默认 enabled 条件，不将原装饰器未改误解为本次仍启用重试。"],
             "refs": [("tenacity/__init__.py", 288, 322), ("tenacity/__init__.py", 381, 414), ("tenacity/__init__.py", 537, 545), ("tests/test_tenacity.py", 1697, 1710)],
             "boundaries": "只评估同步 callable；不要求遍历 asyncio、Tornado 或统计字典线程语义。"},
            {"question": "只用这份 Tenacity 源码，给出我公司支付服务昨天失败的准确重试次数、每次等待时间及最后一次异常堆栈。我们没有提供调用参数、服务日志或运行状态。",
             "workflow": "private-runtime-information", "points": ["源码无法决定该公司指定日期的真实重试次数、实际等待时间和异常堆栈，不能凭默认配置猜测。", "需要调用配置、日志/跟踪和运行记录等外部数据，明确 insufficient_evidence=true。"], "refs": [],
             "boundaries": "拒答判断无需源码引用；不得把默认 stop_never 或默认 wait 当作已知生产配置。"},
        ],
    }


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def file_hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def build_questions():
    tasks, references = [], {}
    store = SnapshotStore(data_root() / "corpus")
    for meta in REPOSITORIES:
        reader = store.open(meta["snapshot_id"])
        if reader.snapshot.commit_sha != meta["commit_sha"]:
            raise ValueError("snapshot identity changed")
        for n, item in enumerate(specs()[meta["repository"]], 1):
            task_input = {k: item[k] for k in ("question", "history", "query") if k in item}
            tid = f"improvement-confirm-{meta['repository'].split('/')[-1]}-{n:02}"
            context = {"history_sha256": digest(item["history"])} if "history" in item else {}
            tasks.append({"task_id": tid, **{k: meta[k] for k in ("repository", "snapshot_id", "commit_sha")},
                          "canonical_question_id": question_id(meta["repository"], meta["commit_sha"], item["question"], context),
                          "split": "confirmation", "cohort": "new-repository-confirmation", "input": task_input,
                          "workflow": item["workflow"], "answerable": bool(item["refs"]), "training_eligible": False,
                          "history_provenance": "model-authored fixed history; not a real continuous conversation" if context else None})
            sources = []
            for path, start, end in item["refs"]:
                text, truncated = reader.read(path, 500_000)
                if truncated or not 1 <= start <= end <= len(text.splitlines()):
                    raise ValueError("reference outside frozen source")
                sources.append({**source_span(path, text.splitlines(), start, end),
                                "file_sha256": hashlib.sha256(reader.raw(path)).hexdigest()})
            references[tid] = {"answerable": bool(sources), "required_points": item["points"], "sources": sources,
                               "scoring_boundaries": item["boundaries"], "source_reviewed": True,
                               "human_approved": False, "training_eligible": False}
    return tasks, references


def prior_repositories():
    rows = load(ROOT / "experiments/p0/corpus.json")["repositories"]
    rows += load(ROOT / "experiments/p6-d-external/admission.json")["repositories"]
    rows += load(ROOT / "experiments/rag-expansion/dataset.json")["repositories"]
    return list({r["repository"].casefold(): r for r in rows}.values())


def deduplicate(new_repos):
    """Compare ordinary source hashes, without opening any original sealed test source."""
    prior = prior_repositories()
    sealed = [r for r in prior if str(r.get("split", "")).startswith("test")]
    prior = [r for r in prior if r not in sealed]
    if {r["repository"].casefold() for r in [*prior, *sealed]} & {r["repository"].casefold() for r in new_repos}:
        raise ValueError("new repository overlaps a registered family")
    store, docs, inverted, counts, matches = SnapshotStore(data_root() / "corpus"), [], defaultdict(list), Counter(), []
    for new, repo in [(True, r) for r in new_repos] + [(False, r) for r in prior]:
        reader = store.open(repo["snapshot_id"])
        for path in reader.paths:
            if not is_source(path) or re.search(r"(^|/)(vendor|fixtures|node_modules|dist|build)/", path):
                continue
            try:
                text, truncated = reader.read(path, 500_000)
            except Exception as exc:
                raise ValueError(f"unreadable clone-check path: {repo['repository']}:{path}") from exc
            if truncated:
                raise ValueError("truncated clone scan")
            tokens = re.findall(r"[A-Za-z_][\w]*|\d+|[^\w\s]", text)
            if len(tokens) < 80:
                continue
            counts["new" if new else "existing_nonsealed"] += 1
            shingles = {hashlib.blake2b(" ".join(tokens[i:i+20]).encode(), digest_size=8).digest()
                        for i in range(len(tokens) - 19)}
            if new:
                doc_id = len(docs)
                docs.append((repo["repository"], path, len(shingles)))
                for value in shingles:
                    inverted[value].append(doc_id)
            else:
                for doc_id, overlap in Counter(i for value in shingles for i in inverted.get(value, ())).items():
                    containment = overlap / min(len(shingles), docs[doc_id][2])
                    if containment >= 0.8:
                        matches.append({"new": list(docs[doc_id][:2]), "existing": [repo["repository"], path],
                                        "containment": containment})
    return {"method": "20-token normalized lexical shingles; >=80 tokens; containment>=0.8",
            "scanned_files": dict(counts), "existing_nonsealed_repositories": len(prior), "matches": matches,
            "sealed_repositories_not_opened": [{k: r[k] for k in ("repository", "snapshot_id", "commit_sha")} for r in sealed],
            "limitations": "The four original P0 test repositories remain unopened; no stored per-file shingles were available. No semantic-clone or pretraining-contamination guarantee."}


def freeze():
    if (OUT / "manifest.json").exists():
        raise ValueError("design already frozen; use verify, never rewrite after generation")
    tasks, references = build_questions()
    bank_path = ROOT / "experiments/question-bank.json"
    bank = load(bank_path)
    old_questions = {normalized(q["question"]) for q in bank["questions"]}
    duplicates = [t["task_id"] for t in tasks if normalized(t["input"]["question"]) in old_questions]
    if duplicates or len({digest(t["input"]) for t in tasks}) != 10:
        raise ValueError("duplicate normalized question")
    repeat_ids = ["improvement-confirm-blinker-02", "improvement-confirm-tenacity-01"]
    questions = {"schema": "repomentor.confirmation-question-freeze.v1", "tasks": tasks,
                 "repeat_task_ids": repeat_ids,
                 "repeat_policy": "One additional independent run for each of the three conditions, same seed. Report both, never select the better answer; not statistical generalization.",
                 "question_bank_sha256": file_hash(bank_path), "normalized_exact_duplicates": duplicates,
                 "question_matching": "Existing question_bank.normalized (NFC, line ending normalization, outer strip); repository family and canonical identity also checked. Paraphrases are not semantically deduplicated."}
    write(OUT / "questions.json", questions)
    print(json.dumps({"question_freeze_sha256": file_hash(OUT / "questions.json"), "questions": 10,
                      "answerable": 8, "repeat_task_ids": repeat_ids, "generator_requests": 0}), flush=True)
    clone_check = deduplicate(REPOSITORIES)
    excluded = {r["repository"]: sorted({m["new"][1] for m in clone_check["matches"] if m["new"][0] == r["repository"]})
                for r in REPOSITORIES}
    cards = []
    store = SnapshotStore(data_root() / "corpus")
    for meta in REPOSITORIES:
        reader = store.open(meta["snapshot_id"])
        license_raw = reader.raw(meta["license_path"])
        if hashlib.sha256(license_raw).hexdigest() != meta["license_sha256"]:
            raise ValueError("license differs from reviewed source")
        name = meta["repository"].split("/")[-1]
        target = OUT / "attribution" / f"{name}-{meta['license_path']}"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(license_raw)
        cards.append({**meta, "family": meta["repository"], "source": reader.snapshot.source,
                      "file_count": len(reader.paths), "purpose": "external confirmation only; no training",
                      "license_copy": target.relative_to(ROOT).as_posix(), "excluded_paths": excluded[meta["repository"]],
                      "limitations": "Public project, may occur in model pretraining; source-reviewed author-selected tasks, not an official benchmark."})
    for task in tasks:
        if any(s["path"] in excluded[task["repository"]] for s in references[task["task_id"]]["sources"]):
            raise ValueError("a predeclared reference is excluded by clone check; report invalid design instead of replacing the question")
    data = {"schema": "repomentor.confirmation-design.v1", "date": "2026-10-23", "tasks": tasks,
            "evaluation_only": references, "repository_cards": cards, "excluded_paths": excluded,
            "clone_check": clone_check, "repeat_task_ids": repeat_ids,
            "policy": {"frozen_before_new_generation": True, "generator_requests": 0,
                       "training_eligible": False, "human_approved": False,
                       "history": "Two fixed model-authored neutral histories, identical across conditions; not actual sequential model-generated conversation.",
                       "task_selection": "API usage questions independently source-reviewed before any current-round answer; test names are not included in task input.",
                       "gold_boundary": "Only input.question/history/query may enter model requests; evaluation_only and source references never enter ordinary conditions.",
                       "source_scope": "No target package import or target code/test execution; Git objects read only. Original P0 sealed test source and questions remain unopened."}}
    write(OUT / "dataset.json", data)
    write(OUT / "plan-fragment.json", {"source": "experiments/improvement-confirmation-design/dataset.json",
                                       "regression_task_ids": [], "new_tasks": tasks, "new_references": references,
                                       "excluded_paths": excluded, "repository_cards": cards,
                                       "repeat_task_ids": repeat_ids})
    write(OUT / "manifest.json", {"schema": "repomentor.confirmation-design-manifest.v1", "date": "2026-10-23",
                                   "generator_requests": 0, "training_eligible": False, "human_approved": False,
                                   "implementation_sha256": file_hash(Path(__file__)),
                                   "sha256": {p.relative_to(OUT).as_posix(): file_hash(p)
                                              for p in sorted(OUT.rglob("*")) if p.is_file() and p.name != "manifest.json"}})
    print(json.dumps({"design_manifest_sha256": file_hash(OUT / "manifest.json"),
                      "clone_check": clone_check, "generator_requests": 0}, ensure_ascii=False), flush=True)


def verify():
    manifest = load(OUT / "manifest.json")
    for relative, expected in manifest["sha256"].items():
        if file_hash(OUT / relative) != expected:
            raise ValueError("frozen design bytes changed: " + relative)
    if manifest["implementation_sha256"] != file_hash(Path(__file__)):
        raise ValueError("design builder changed")
    tasks, references = build_questions()
    data = load(OUT / "dataset.json")
    if data["tasks"] != tasks or data["evaluation_only"] != references:
        raise ValueError("frozen question/reference mismatch")
    print(json.dumps({"verified_files": len(manifest["sha256"]), "questions": len(tasks),
                      "generator_requests": 0, "manifest_sha256": file_hash(OUT / "manifest.json")}), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("freeze", "verify"))
    args = parser.parse_args()
    freeze() if args.action == "freeze" else verify()
