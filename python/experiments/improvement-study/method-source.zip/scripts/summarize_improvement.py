"""Derive a read-only, source-bound study report from saved benchmark reviews."""

import argparse
import hashlib
import inspect
import itertools
import json
import math
import socket
import statistics
from collections import Counter, defaultdict
from pathlib import Path

from repomentor.semantic_review import quality_tiers

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_BATCHES = ("experiments/improvement-finalization", "experiments/improvement-confirmation")
METRICS = ("factually_correct", "core_supported", "fully_resolved", "completeness_adequate")


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def fingerprint(value):
    return sha(json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode())


def wilson(successes, total):
    if not total:
        return None
    z = statistics.NormalDist().inv_cdf(0.975)
    proportion = successes / total
    denominator = 1 + z * z / total
    center = (proportion + z * z / (2 * total)) / denominator
    radius = z * math.sqrt(proportion * (1 - proportion) / total + z * z / (4 * total * total)) / denominator
    return [max(0, center - radius), min(1, center + radius)]


def binomial_cdf(k, n, probability):
    return sum(math.comb(n, i) * probability ** i * (1 - probability) ** (n - i) for i in range(k + 1))


def exact_discordant_interval(wins, losses):
    """Clopper-Pearson interval for P(candidate wins | a discordant pair)."""
    n = wins + losses
    if not n:
        return None

    def solve(function, target, increasing):
        left, right = 0.0, 1.0
        for _ in range(60):
            middle = (left + right) / 2
            if (function(middle) < target) == increasing:
                left = middle
            else:
                right = middle
        return (left + right) / 2

    lower = 0.0 if wins == 0 else solve(lambda p: 1 - binomial_cdf(wins - 1, n, p), 0.025, True)
    upper = 1.0 if wins == n else solve(lambda p: binomial_cdf(wins, n, p), 0.025, False)
    return [lower, upper]


def numbers(values):
    known = [v for v in values if isinstance(v, (int, float))]
    return {"observed": len(known), "missing": len(values) - len(known),
            "sum": sum(known) if known else None, "median": statistics.median(known) if known else None,
            "minimum": min(known) if known else None, "maximum": max(known) if known else None}


class Inputs:
    def __init__(self):
        self.hashes, self.missing = {}, []

    def raw(self, path, optional=False):
        path = Path(path).resolve()
        if not path.is_relative_to(ROOT):
            raise ValueError("input outside Python workspace")
        relative = path.relative_to(ROOT).as_posix()
        if not path.exists() and optional:
            self.missing.append(relative)
            return None
        raw = path.read_bytes()
        self.hashes[relative] = sha(raw)
        return raw

    def json(self, path, optional=False):
        raw = self.raw(path, optional)
        return json.loads(raw) if raw is not None else None


def source_lines(spans):
    """Only real nonblank source text counts; range metadata alone does not."""
    result = {}
    for span in spans:
        start = span["start_line"]
        lines = span.get("lines")
        if lines is None:
            lines = span.get("content", "").split("\n")
        for number, line in enumerate(lines, start):
            prefix = f"L{number}: "
            if line.startswith(prefix):
                line = line[len(prefix):]
            if number > span["end_line"] or not line.strip():
                continue
            key = (span["path"], number)
            if key in result and result[key] != line:
                raise ValueError("inconsistent source bytes in an immutable line")
            result[key] = line
    return result


def reference_complete(references, spans):
    if not references:
        return {"strict_ranges": None, "nonblank_lines": None}
    actual = source_lines(spans)
    nonblank = source_lines(references)
    covered = {(s["path"], line) for s in spans for line in range(s["start_line"], s["end_line"] + 1)}
    strict = all((ref["path"], line) in covered for ref in references
                 for line in range(ref["start_line"], ref["end_line"] + 1))
    return {"strict_ranges": strict, "nonblank_lines": all(actual.get(key) == value for key, value in nonblank.items())}


def tool_evidence(result, initial, final):
    seen, retained = source_lines(initial), source_lines(final)
    tools = []
    for trace in result.get("tool_trace", []):
        action, observation = trace.get("action", {}), trace.get("observation", {})
        delivered = source_lines(observation.get("spans", []))
        if any(key in seen and seen[key] != line for key, line in delivered.items()):
            raise ValueError("tool source differs from previously delivered immutable source")
        novel = {key: line for key, line in delivered.items() if key not in seen}
        tools.append({"call_id": action.get("call_id"), "tool": action.get("tool"),
                      "status": observation.get("status"), "error_code": observation.get("error_code"),
                      "delivered_nonblank_lines": len(delivered), "new_nonblank_lines": len(novel),
                      "new_nonblank_lines_retained_final": sum(retained.get(key) == line for key, line in novel.items()),
                      "effective_new_source": bool(novel),
                      "new_source_ranges": compact_ranges(novel)})
        seen.update(delivered)
    return {"declared_tool_calls": result.get("tool_calls", 0), "observed_tool_calls": len(tools),
            "effective_calls": sum(t["effective_new_source"] for t in tools),
            "already_read_calls": sum(t["error_code"] == "already_read" for t in tools),
            "calls_without_new_nonblank_source": sum(not t["effective_new_source"] for t in tools),
            "new_nonblank_lines": sum(t["new_nonblank_lines"] for t in tools),
            "new_nonblank_lines_retained_final": sum(t["new_nonblank_lines_retained_final"] for t in tools),
            "calls": tools}


def compact_ranges(lines):
    result = []
    for path, number in sorted(lines):
        if result and result[-1]["path"] == path and result[-1]["end_line"] + 1 == number:
            result[-1]["end_line"] = number
        else:
            result.append({"path": path, "start_line": number, "end_line": number})
    return result


def costs(result):
    calls = result.get("decisions", [result["completion"]])
    sent = [call for call in calls if call.get("request_sent") is True]
    cache_hit = result.get("cache_hit") is True
    current = [] if cache_hit else sent
    requests = result.get("new_model_requests")
    return {"new_requests": requests, "cache_hit": result.get("cache_hit"),
            "saved_decisions": len(calls), "observed_current_sent_calls": len(current),
            "requests_without_matching_call": max(0, requests - len(current)) if requests is not None else None,
            "prompt_tokens": numbers([(call.get("usage") or {}).get("prompt_tokens") for call in current]),
            "completion_tokens": numbers([(call.get("usage") or {}).get("completion_tokens") for call in current]),
            "generator_elapsed_seconds": numbers([call.get("elapsed_seconds") for call in current]),
            "evaluation_elapsed_seconds": result.get("evaluation_elapsed_seconds"),
            "cache_usage_note": "Cached stored decisions do not count as newly sent usage." if cache_hit else None}


def case_details(data, case, row, review):
    task = next(t for t in data["tasks"] if t["task_id"] == case["task_id"])
    base = {**case, "repository": task["repository"], "answerable": task["answerable"],
            "cohort": task["cohort"], "workflow": task.get("workflow"),
            "replicate": case.get("replicate", 0), "pending_result": row is None,
            "pending_review": review is None, "quality": None}
    if row is None:
        return base
    result = row["result"]
    if any(row[k] != case[k] for k in ("case_id", "task_id", "condition")):
        raise ValueError("result identity differs from declared case")
    if review is not None and review.get("result_sha256") != fingerprint(row):
        raise ValueError("review is bound to different result bytes")
    initial = data["prepared_inputs"][case["case_id"]]["context"]
    final = result["final_context"] if "final_context" in result else result.get("context", [])
    references = data["evaluation_only"][case["task_id"]]["sources"]
    completion = result["completion"]
    answer = result.get("answer")
    base.update({"result_sha256": fingerprint(row), "workflow_status": completion["status"],
                 "error_code": completion.get("error_code"), "stop_reason": result.get("stop_reason"),
                 "finish_reason": completion.get("finish_reason"), "answer_present": answer is not None,
                 "answer_json_sha256": fingerprint(answer) if answer is not None else None,
                 "citation_ranges_valid": result.get("citation_ranges_valid"),
                 "insufficient_evidence": answer.get("insufficient_evidence") if answer else None,
                 "initial_reference_complete": reference_complete(references, initial),
                 "final_reference_complete": reference_complete(references, final),
                 "tool_evidence": tool_evidence(result, initial, final), "cost": costs(result),
                 "raw_failure": completion if completion["status"] != "success" or answer is None else None})
    if review is not None:
        base.update({"quality": {"factually_correct": review["correctness"] == "correct",
                                  **quality_tiers(review, completion["status"]),
                                  "completeness_adequate": review["completeness"] == "adequate"},
                     "review": {k: review.get(k) for k in ("correctness", "citation_support", "completeness",
                                "abstention", "entry_scope", "consistency", "notes", "review_type", "human_approved")}})
    return base


def group_details(cases):
    observed = [c for c in cases if not c["pending_result"]]
    reviewed = [c for c in cases if c["quality"] is not None]
    complete = len(reviewed) == len(cases)
    metrics = {name: {"successes": sum(c["quality"][name] for c in reviewed) if complete else None,
                      "denominator": len(cases), "wilson95": wilson(sum(c["quality"][name] for c in reviewed), len(cases)) if complete else None}
               for name in METRICS}
    usage = {}
    for name in ("prompt_tokens", "completion_tokens", "generator_elapsed_seconds"):
        values = [c["cost"][name] for c in observed]
        sums = [v["sum"] for v in values if v["sum"] is not None]
        usage[name] = {"observed_sum": sum(sums) if sums else None,
                       "calls_observed": sum(v["observed"] for v in values),
                       "calls_missing": sum(v["missing"] for v in values)}
    with_new = [c for c in observed if c["tool_evidence"]["effective_calls"]]
    without_new = [c for c in observed if not c["tool_evidence"]["effective_calls"]]
    return {"status": "complete" if complete else "pending", "planned": len(cases), "observed": len(observed),
            "reviewed": len(reviewed), "quality": metrics,
            "workflow_statuses": dict(Counter(c["workflow_status"] for c in observed)),
            "insufficient_evidence_flags": dict(Counter(str(c["insufficient_evidence"]) for c in observed)),
            "new_requests": sum(c["cost"]["new_requests"] or 0 for c in observed),
            "new_request_count_missing_cases": sum(c["cost"]["new_requests"] is None for c in observed),
            "cache_hits": sum(c["cost"]["cache_hit"] is True for c in observed),
            "cache_status_unknown": sum(c["cost"]["cache_hit"] is None for c in observed),
            "requests_without_matching_call": sum(c["cost"]["requests_without_matching_call"] or 0 for c in observed),
            "usage": usage, "evaluation_elapsed_seconds": numbers([c["cost"]["evaluation_elapsed_seconds"] for c in observed]),
            "initial_reference_complete": {k: sum(c["initial_reference_complete"][k] is True for c in observed) for k in ("strict_ranges", "nonblank_lines")},
            "final_reference_complete": {k: sum(c["final_reference_complete"][k] is True for c in observed) for k in ("strict_ranges", "nonblank_lines")},
            "tools": {k: sum(c["tool_evidence"][k] for c in observed) for k in ("declared_tool_calls", "observed_tool_calls", "effective_calls", "already_read_calls", "calls_without_new_nonblank_source", "new_nonblank_lines", "new_nonblank_lines_retained_final")},
            "source_gain_association": {name: {"episodes": len(rows), "reviewed": sum(c["quality"] is not None for c in rows),
                                               "fully_resolved": sum(c["quality"]["fully_resolved"] for c in rows if c["quality"] is not None)}
                                        for name, rows in (("new_source", with_new), ("no_new_source", without_new))}}


def paired(cases):
    conditions = sorted({c["condition"] for c in cases})
    order = {"finalizer_control": 0, "finalizer_candidate": 1, "bm25_code": 0, "agentic_no_tools": 1, "agentic": 2}
    conditions.sort(key=lambda c: order.get(c, 99))
    result = []
    indexed = {(c["task_id"], c["condition"]): c for c in cases}
    tasks = sorted({c["task_id"] for c in cases})
    for control, candidate in itertools.combinations(conditions, 2):
        rows = {}
        for metric in METRICS:
            tally = {key: [] for key in ("wins", "losses", "both_pass", "both_fail", "pending")}
            for tid in tasks:
                left, right = indexed.get((tid, control)), indexed.get((tid, candidate))
                if left is None or right is None or left["quality"] is None or right["quality"] is None:
                    tally["pending"].append(tid)
                    continue
                a, b = left["quality"][metric], right["quality"][metric]
                tally["both_pass" if a and b else "both_fail" if not a and not b else "wins" if b else "losses"].append(tid)
            wins, losses = len(tally["wins"]), len(tally["losses"])
            n = wins + losses
            rows[metric] = {"task_ids": tally, "counts": {k: len(v) for k, v in tally.items()},
                            "win_probability_given_discordance_exact95": exact_discordant_interval(wins, losses),
                            "two_sided_binomial_p": min(1.0, 2 * binomial_cdf(min(wins, losses), n, 0.5)) if n else None}
        result.append({"control": control, "candidate": candidate, "metrics": rows})
    return result


def repeat_stability(cases):
    first = {(c["task_id"], c["condition"]): c for c in cases if not c["replicate"]}
    result = []
    for repeat in sorted((c for c in cases if c["replicate"]), key=lambda c: (c["task_id"], c["condition"])):
        original = first[(repeat["task_id"], repeat["condition"])]
        reviewed = original["quality"] is not None and repeat["quality"] is not None
        result.append({"task_id": repeat["task_id"], "condition": repeat["condition"],
                       "first_case_id": original["case_id"], "repeat_case_id": repeat["case_id"],
                       "first_quality": original["quality"], "repeat_quality": repeat["quality"],
                       "same_quality": original["quality"] == repeat["quality"] if reviewed else None,
                       "same_answer_json": original.get("answer_json_sha256") == repeat.get("answer_json_sha256")
                       if original.get("answer_present") and repeat.get("answer_present") else None})
    return result


def load_batch(folder, inputs):
    folder = Path(folder).resolve()
    data = inputs.json(folder / "dataset.json")
    raw = inputs.raw(folder / "results.jsonl", optional=True)
    rows, incomplete_trailing = [], False
    raw_lines = (raw or b"").splitlines()
    for line_number, line in enumerate(raw_lines):
        if not line.strip():
            continue
        try:
            rows.append(json.loads(line))
        except (json.JSONDecodeError, UnicodeDecodeError):
            if line_number != len(raw_lines) - 1:
                raise
            incomplete_trailing = True
    if len({r["case_id"] for r in rows}) != len(rows):
        raise ValueError("duplicate saved result")
    summary = inputs.json(folder / "summary.json", optional=True)
    sealed = inputs.json(folder / "completed-files.json", optional=True)
    if sealed:
        for name, expected in sealed["sha256"].items():
            if inputs.hashes.get((folder / name).relative_to(ROOT).as_posix()) != expected:
                raise ValueError("frozen benchmark input hash differs")
    for key in ("source", "replay_source"):
        source = data["protocol"].get(key, data.get("declared_plan", {}).get(key))
        expected = data["protocol"].get(key + "_sha256", data.get("declared_plan", {}).get(key + "_sha256"))
        if source:
            content = inputs.raw(ROOT / source)
            if expected and sha(content) != expected:
                raise ValueError("declared source package changed")
    results = {r["case_id"]: r for r in rows}
    reviews = (summary or {}).get("reviews", {})
    declared = {c["case_id"] for c in data["cases"]}
    if len(declared) != len(data["cases"]):
        raise ValueError("duplicate declared case identity")
    if set(results) - declared or set(reviews) - set(results):
        raise ValueError("undeclared result or unbound review")
    if summary and summary["planned_answers"] != len(declared):
        raise ValueError("summary and declared case counts differ")
    summary_counts_stale = bool(summary and summary["records"] != len(rows))
    if sealed and summary_counts_stale:
        raise ValueError("sealed summary and saved record counts differ")
    cases = [case_details(data, c, results.get(c["case_id"]), reviews.get(c["case_id"])) for c in data["cases"]]
    for condition in {c["condition"] for c in cases}:
        selected = [c for c in cases if c["condition"] == condition]
        if summary and all(c["quality"] is not None for c in selected):
            saved = summary["groups"]["all/" + condition]
            for metric in ("factually_correct", "core_supported", "fully_resolved"):
                if sum(c["quality"][metric] for c in selected) != saved.get(metric, 0):
                    raise ValueError("derived quality tiers differ from saved summary: " + metric)
    groups = defaultdict(list)
    for case in cases:
        part = "repeat" if case["replicate"] else "first_answerable" if case["answerable"] else "first_private"
        groups[(part, case["condition"])].append(case)
    statistics_by_group = {part + "/" + condition: group_details(items) for (part, condition), items in sorted(groups.items())}
    comparisons = {part: paired([c for c in cases if ("repeat" if c["replicate"] else "first_answerable" if c["answerable"] else "first_private") == part])
                   for part in ("first_answerable", "first_private", "repeat")}
    complete = bool(sealed) and len(rows) == len(cases) == len(reviews)
    return {"batch": folder.name, "status": "complete" if complete else "pending", "planned": len(cases),
            "observed": len(rows), "reviewed": len(reviews), "sealed": bool(sealed),
            "incomplete_trailing_record_ignored": incomplete_trailing,
            "summary_counts_stale": summary_counts_stale,
            "settings": data["protocol"]["settings"], "implementation": data["protocol"]["implementation"],
            "scope": data["protocol"]["scope"], "limits": data["protocol"]["limits"],
            "retrieval_devices": sorted({p.get("device", "unknown") for p in data["policies"].values()}),
            "review_origin": "Saved summary reviews; current quality_tiers helper, with its source hash bound below.",
            "groups": statistics_by_group, "paired": comparisons,
            "repeat_stability": repeat_stability(cases),
            "ledger_new_requests": (summary or {}).get("new_requests"),
            "paid_requests": (summary or {}).get("paid_requests"),
            "recorded_new_requests": sum(r["result"].get("new_model_requests", 0) for r in rows),
            "max_new_requests": data["protocol"]["max_new_requests"],
            "finalization_gate": data.get("declared_plan", {}).get("finalization_gate"),
            "raw_failure_case_ids": [c["case_id"] for c in cases if c.get("raw_failure") is not None]}, cases


def proportion(metric):
    return "pending" if metric["successes"] is None else f"{metric['successes']}/{metric['denominator']}"


def interval_text(interval):
    return "—" if interval is None else f"{interval[0]:.0%}–{interval[1]:.0%}"


def markdown(report, cases):
    saved_requests = sum(b["recorded_new_requests"] for b in report["batches"])
    lines = ["# 非后训练阶段：离线派生报告", "",
             f"状态：**{report['status']}**。本报告生成不调用模型；所汇总回答记录实际新增 {saved_requests} 次模型请求。真人参与者 0。", "",
             "语义判断只来自已绑定原始结果的源码评审；格式成功、引用行号合法和参考覆盖不替代答案正确性。两个批次、首次与重复分别展示。", ""]
    for batch in report["batches"]:
        lines += [f"## {batch['batch']}", "", f"{batch['status']}；输出 {batch['observed']}/{batch['planned']}，已评审 {batch['reviewed']}，封存 {batch['sealed']}。", "", batch["scope"], "",
                  "| 分组/条件 | 事实 | 核心 | 完整解决 | 完整解决 Wilson 95% | 完整性 adequate / Wilson95% | 新请求 | 已观测输入/输出 token | 统一整段耗时中位数秒 |", "| --- | --- | --- | --- | --- | --- | --- | --- | --- |"]
        for name, group in batch["groups"].items():
            q, usage, elapsed = group["quality"], group["usage"], group["evaluation_elapsed_seconds"]
            timing = f"{elapsed['median']:.1f}" if elapsed["median"] is not None else "unknown"
            lines.append(f"| {name} | {proportion(q['factually_correct'])} | {proportion(q['core_supported'])} | {proportion(q['fully_resolved'])} | {interval_text(q['fully_resolved']['wilson95'])} | {proportion(q['completeness_adequate'])} / {interval_text(q['completeness_adequate']['wilson95'])} | {group['new_requests']} | {usage['prompt_tokens']['observed_sum']}/{usage['completion_tokens']['observed_sum']} | {timing} |")
        lines += ["", "区间仅是对当前小样本计数的二项假设描述；题目由实现者选择，不能当作总体准确率区间。pending 分组不把缺评审算成错误或成功。", "",
                  "| 分组 | 对照→候选 | 事实增/失 | 核心增/失 | 完整增/失/双过/双未过/待评 | 不一致对中候选胜率精确95% |", "| --- | --- | --- | --- | --- | --- |"]
        for part, comparisons in batch["paired"].items():
            for comparison in comparisons:
                metric = comparison["metrics"]["fully_resolved"]
                counts = metric["counts"]
                tally = "/".join(str(counts[k]) for k in ("wins", "losses", "both_pass", "both_fail", "pending"))
                fact = comparison["metrics"]["factually_correct"]["counts"]
                core = comparison["metrics"]["core_supported"]["counts"]
                lines.append(f"| {part} | {comparison['control']}→{comparison['candidate']} | {fact['wins']}/{fact['losses']} | {core['wins']}/{core['losses']} | {tally} | {interval_text(metric['win_probability_given_discordance_exact95'])} |")
        if batch["repeat_stability"]:
            lines += ["", "| 预选重复题/条件 | 首次完整→重复完整 | 四项质量分档相同 | 答案 JSON 相同 |", "| --- | --- | --- | --- |"]
            for repeat in batch["repeat_stability"]:
                first = repeat["first_quality"]["fully_resolved"] if repeat["first_quality"] else "pending"
                second = repeat["repeat_quality"]["fully_resolved"] if repeat["repeat_quality"] else "pending"
                lines.append(f"| {repeat['task_id']}/{repeat['condition']} | {first}→{second} | {repeat['same_quality']} | {repeat['same_answer_json']} |")
        lines += ["", "| 分组/条件 | 初始→最终参考非空行全部覆盖 | 工具调用/有效新增/已读重复 | 新增非空行/最终保留 | 新取证 episode 中完整解决 | 无新取证 episode 中完整解决 | cache hit |", "| --- | --- | --- | --- | --- | --- | --- |"]
        for name, group in batch["groups"].items():
            tools, assoc = group["tools"], group["source_gain_association"]
            lines.append(f"| {name} | {group['initial_reference_complete']['nonblank_lines']}→{group['final_reference_complete']['nonblank_lines']} | {tools['observed_tool_calls']}/{tools['effective_calls']}/{tools['already_read_calls']} | {tools['new_nonblank_lines']}/{tools['new_nonblank_lines_retained_final']} | {assoc['new_source']['fully_resolved']}/{assoc['new_source']['reviewed']} | {assoc['no_new_source']['fully_resolved']}/{assoc['no_new_source']['reviewed']} | {group['cache_hits']} |")
        failures = [c for c in cases if c["batch"] == batch["batch"] and c.get("raw_failure") is not None]
        lines += ["", "原始失败：" + ("无已保存失败。" if not failures else ""), ""]
        for case in failures:
            lines.append(f"- `{case['case_id']}`：{case['workflow_status']}；error={case['error_code']}；finish={case['finish_reason']}；stop={case['stop_reason']}；answer_present={case['answer_present']}。原始 completion 保留在 cases.json。")
        private = [c for c in cases if c["batch"] == batch["batch"] and not c["answerable"]]
        if private:
            lines += ["", "| 私有信息 case | 评审事实/拒答 | insufficient_evidence |", "| --- | --- | --- |"]
            for case in private:
                review = case.get("review", {})
                lines.append(f"| {case['case_id']} | {review.get('correctness', 'pending')}/{review.get('abstention', 'pending')} | {case.get('insufficient_evidence', 'pending')} |")
        if batch["finalization_gate"]:
            gate = batch["finalization_gate"]
            lines += ["", "P2 门槛结论：" + gate["decision"], "", gate.get("blocking_criterion", ""), ""]
    lines += ["## 口径与限制", "",
              "- evaluation_elapsed_seconds 使用各 case 相同外围计时；保存的 generator 耗时另列。未知 token/耗时保持缺失计数，缓存记录不伪装成新请求成本。模型与量化、上下文、seed、决策/工具上限、设备声明保留在 summary.json。",
              "- 工具有效新增要求返回此前未见的非空原文行；工具名称、命中元数据或合法行号不算新增。还报告新增行在最终输入的保留数。该指标不保证语义相关、被正确使用或带来因果收益。",
              "- 参考完整度只是预设行段覆盖代理；有效替代来源可能不在参考中。空 final_context 保持为空，不能用曾读内容补齐本次可见证据。",
              "- 工具开/关匹配阶段策略和上限，实际路径可能提前结束；固定单次 RAG 与多次推理 SDK 的差异不能全部归因于工具。相同 seed 的两题重复只显示运行稳定性，不扩大独立样本数。",
              "- 模型辅助评审与子 Agent 复核不改称人审；没有真人节时、满意度或 ROI 测量。两个新公开仓库仍可能出现在预训练数据中，原最终测试保持封存。",
              "- 全部数据不进入 SFT/DPO/GRPO，未开展后训练。P2 候选不通过保护门槛时保留原默认，不根据新确认结果再追调。", "",
              "硬件与冷/热声明：", "", "```json", json.dumps(report["hardware"], ensure_ascii=False, indent=2), "```", ""]
    return "\n".join(lines)


def verify_output(folder):
    manifest = json.loads((folder / "manifest.json").read_text(encoding="utf-8"))
    for name, expected in manifest["inputs_sha256"].items():
        if sha((ROOT / name).read_bytes()) != expected:
            raise ValueError("report input changed: " + name)
    for name, expected in manifest["sha256"].items():
        if sha((folder / name).read_bytes()) != expected:
            raise ValueError("report output changed: " + name)
    print(json.dumps({"verified_inputs": len(manifest["inputs_sha256"]), "verified_outputs": len(manifest["sha256"]), "generator_requests": 0}))


def main():
    def blocked(*args, **kwargs):
        raise RuntimeError("study summarization is offline; network access is forbidden")

    socket.socket.connect = blocked
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--batch", type=Path, action="append")
    parser.add_argument("--output", type=Path, default=ROOT / "experiments/improvement-study/report")
    parser.add_argument("--hardware-file", type=Path)
    parser.add_argument("--require-complete", action="store_true")
    parser.add_argument("--verify", type=Path)
    args = parser.parse_args()
    if args.verify:
        verify_output(args.verify.resolve())
        return
    batches = [p.resolve() for p in args.batch] if args.batch else [ROOT / p for p in DEFAULT_BATCHES]
    output = args.output.resolve()
    if output.exists() or not output.is_relative_to(ROOT) or any(output.is_relative_to(b) or b.is_relative_to(output) for b in batches):
        raise ValueError("choose a new report directory outside all source batches, inside Python")
    inputs = Inputs()
    inputs.raw(Path(__file__))
    inputs.raw(Path(inspect.getfile(quality_tiers)))
    protocol_note = ROOT / "notes/improvement-study-protocol.md"
    inputs.raw(protocol_note, optional=True)
    hardware = inputs.json(args.hardware_file) if args.hardware_file else {
        "cpu": "not recorded in batch metadata", "gpu": "not recorded in batch metadata",
        "generator_warm_state": "not recorded per case", "retrieval_cache_state": "not recorded per case",
        "declaration": "Per-case cache_hit is reported; no cold-start/warm-start or hardware equality claim is inferred."}
    reports, cases = [], []
    for batch in batches:
        report, batch_cases = load_batch(batch, inputs)
        reports.append(report)
        cases.extend({"batch": batch.name, **case} for case in batch_cases)
    complete = all(b["status"] == "complete" for b in reports)
    if args.require_complete and not complete:
        raise ValueError("pending results, source reviews, or sealed batch manifest; no report written")
    summary = {"schema": "repomentor.improvement-study.v1", "status": "complete" if complete else "pending",
               "generator_requests": 0, "human_participants": 0, "human_approved": False, "training_eligible": False,
               "batches": reports, "hardware": hardware,
               "statistics_note": "95% Wilson intervals describe each condition's recorded counts. Paired exact intervals concern conditional win probability among discordant pairs, not an effect-size confidence interval. Selected tiny samples do not establish population accuracy or causal benefit."}
    output.mkdir(parents=True)
    for name, value in (("summary.json", summary), ("cases.json", cases)):
        (output / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (output / "report.md").write_text(markdown(summary, cases), encoding="utf-8")
    manifest = {"schema": "repomentor.improvement-study-manifest.v1", "status": summary["status"],
                "inputs_sha256": inputs.hashes, "missing_inputs": inputs.missing,
                "sha256": {name: sha((output / name).read_bytes()) for name in ("summary.json", "cases.json", "report.md")},
                "generator_requests": 0, "human_participants": 0, "training_eligible": False}
    (output / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": summary["status"], "output": output.relative_to(ROOT).as_posix(),
                      "batches": [{k: b[k] for k in ("batch", "status", "planned", "observed", "reviewed")} for b in reports],
                      "generator_requests": 0}, ensure_ascii=False))


if __name__ == "__main__":
    main()
