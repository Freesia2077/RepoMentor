"""Check frozen experiment bytes offline; no model settings, SDK or inference required."""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def verify(root=ROOT):
    root = Path(root).resolve()
    manifests = [
        (root, root / "experiments/p63/protocol.json", "protected_files"),
        (root / "experiments/p63", root / "experiments/p63/completed-files.json", "sha256"),
        (root / "experiments/p63-closeout", root / "experiments/p63-closeout/completed-files.json", "sha256"),
        (root / "experiments/qwen9b-diagnostic", root / "experiments/qwen9b-diagnostic/completed-files.json", "sha256"),
    ]
    for name in ("qwen9b-reliability", "qwen9b-followup", "rag-interview", "rag-expansion", "rag-unified", "rag-system", "rag-refinement", "rag-recovery", "rag-consolidation", "improvement-finalization", "improvement-confirmation"):
        manifest = root / "experiments" / name / "completed-files.json"
        if manifest.is_file():
            manifests.append((manifest.parent, manifest, "sha256"))
    for manifest in sorted((root / "experiments/workflow-diagnosis").glob("*/manifest.json")):
        manifests.append((manifest.parent, manifest, "sha256"))
    manifest = root / "experiments/improvement-confirmation-design/manifest.json"
    if manifest.is_file():
        manifests.append((manifest.parent, manifest, "sha256"))
    counts = {}
    for base, manifest, key in manifests:
        entries = json.loads(manifest.read_text(encoding="utf-8"))[key]
        for name, expected in entries.items():
            path = (base / name).resolve()
            if not path.is_relative_to(base.resolve()):
                raise ValueError("archive path escapes its root")
            if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
                raise ValueError(f"archived result changed: {path.relative_to(root)}")
        counts[str(manifest.relative_to(root))] = len(entries)
    result = {"verified_files": sum(counts.values()), "manifests": counts, "model_requests": 0}
    print(json.dumps(result))
    return result


if __name__ == "__main__":
    verify()
