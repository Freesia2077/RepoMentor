"""Bound archived observations stay distinct from semantic truth and historical scores."""

import hashlib
import json
import subprocess
import sys

import pytest

from repomentor.experiment_review import diagnose_saved
from repomentor.runtimes.chat import fingerprint


def seal(folder, files):
    folder.mkdir()
    for name, value in files.items():
        text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False)
        (folder / name).write_text(text, encoding="utf-8")
    hashes = {name: hashlib.sha256((folder / name).read_bytes()).hexdigest() for name in files}
    (folder / "completed-files.json").write_text(json.dumps({"sha256": hashes}), encoding="utf-8")
    return hashes


@pytest.fixture
def batch(tmp_path):
    full = {"path": "main.py", "start_line": 1, "end_line": 2, "content": "if enabled:\n    return 1"}
    first = {**full, "end_line": 1, "content": "if enabled:"}
    tasks, rows, reviews, prepared, evaluation = [], [], {}, {}, {}
    for name, initial, status in (("wrong", full, "success"), ("gap", first, "success"), ("failed", full, "failed")):
        cid = name + "--agentic"
        tasks.append({"task_id": name, "split": "validation", "cohort": "development", "answerable": True,
                      "input": {"question": "关闭时会返回什么？"}})
        result = {"context": [initial], "final_context": [] if status == "failed" else [initial],
                  "completion": {"status": status, "error_code": "invalid_citations" if status == "failed" else None},
                  "tool_trace": [], "tool_calls": 0, "new_model_requests": 2, "answer": None,
                  "initial_retrieval": {"retrieval": {"candidates": [{"chunk": initial}]}}}
        row = {"case_id": cid, "task_id": name, "condition": "agentic", "repository": "example/repo", "result": result}
        rows.append(row)
        reviews[cid] = {"result_sha256": fingerprint(row), "correctness": "incorrect" if status == "success" else "unverifiable",
                        "completeness": "adequate" if status == "success" else "unverifiable",
                        "citation_support": "unsupported" if status == "success" else "unverifiable",
                        "abstention": "not_applicable", "notes": "原始模型非盲评审"}
        prepared[cid] = {"context": [initial]}
        evaluation[name] = {"sources": [full], "required_points": ["必须核对条件"]}
    files = {"dataset.json": {"tasks": tasks, "prepared_inputs": prepared, "evaluation_only": evaluation},
             "results.jsonl": "\n".join(json.dumps(row, ensure_ascii=False) for row in rows),
             "summary.json": {"records": 3, "reviews": reviews,
                              "groups": {"answerable/agentic": {"records": 3, "core_supported": 0, "fully_resolved": 0}}}}
    folder = tmp_path / "source"
    hashes = seal(folder, files)
    return folder, hashes


def test_diagnosis_separates_evidence_generation_and_workflow_without_rewriting(batch, tmp_path):
    source, before = batch
    summary = diagnose_saved(source, tmp_path / "diagnosis")
    cases = {row["task_id"]: row for row in json.loads((tmp_path / "diagnosis/cases.json").read_text(encoding="utf-8"))}
    assert "reference_complete_fact_error" in cases["wrong"]["signals"]
    assert "reference_gap_at_input" not in cases["wrong"]["signals"]
    assert "agent_gap_without_new_source" in cases["gap"]["signals"]
    assert "workflow_failure" in cases["failed"]["signals"]
    assert "reference_complete_fact_error" not in cases["failed"]["signals"]
    assert cases["failed"]["review"]["correctness"] == "unverifiable"
    assert cases["failed"]["reference_nonblank_complete"]["final"] is False
    assert summary["records"] == 3 and summary["model_requests"] == 0
    assert {name: hashlib.sha256((source / name).read_bytes()).hexdigest() for name in before} == before


def test_diagnosis_preserves_frozen_tiers_instead_of_applying_current_rubric(batch, tmp_path):
    source, _ = batch
    summary = json.loads((source / "summary.json").read_text(encoding="utf-8"))
    summary["groups"]["answerable/agentic"]["core_supported"] = 1
    (source / "summary.json").write_text(json.dumps(summary), encoding="utf-8")
    manifest = json.loads((source / "completed-files.json").read_text(encoding="utf-8"))
    manifest["sha256"]["summary.json"] = hashlib.sha256((source / "summary.json").read_bytes()).hexdigest()
    (source / "completed-files.json").write_text(json.dumps(manifest), encoding="utf-8")
    result = diagnose_saved(source, tmp_path / "diagnosis")
    assert result["groups"]["answerable/agentic"]["core_supported"] == 1


@pytest.mark.parametrize("failure", ("bytes", "review", "test_split", "inside_source"))
def test_diagnosis_rejects_untrusted_or_sealed_inputs(batch, tmp_path, failure):
    source, _ = batch
    destination = tmp_path / "diagnosis"
    if failure == "inside_source":
        destination = source / "diagnosis"
    elif failure == "bytes":
        (source / "results.jsonl").write_text("changed", encoding="utf-8")
    else:
        filename = "summary.json" if failure == "review" else "dataset.json"
        data = json.loads((source / filename).read_text(encoding="utf-8"))
        if failure == "review":
            data["reviews"]["wrong--agentic"]["result_sha256"] = "wrong"
        else:
            data["tasks"][0]["split"] = "test"
        (source / filename).write_text(json.dumps(data), encoding="utf-8")
        manifest = json.loads((source / "completed-files.json").read_text(encoding="utf-8"))
        manifest["sha256"][filename] = hashlib.sha256((source / filename).read_bytes()).hexdigest()
        (source / "completed-files.json").write_text(json.dumps(manifest), encoding="utf-8")
    with pytest.raises(ValueError):
        diagnose_saved(source, destination)
    assert not destination.exists()


def test_question_runtime_imports_without_evaluation_or_legacy_report():
    code = """
import sys
sys.modules['repomentor.evaluation'] = None
sys.modules['repomentor.harness'] = None
from repomentor.rag import RagEngine
from repomentor.sdk_agent import SdkAgentEngine
from repomentor.agent_tools import RepositoryEnvironment
assert RagEngine and SdkAgentEngine and RepositoryEnvironment
"""
    subprocess.run([sys.executable, "-s", "-c", code], check=True, capture_output=True, text=True)
