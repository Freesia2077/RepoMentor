"""One-schema intervention and same-flow tool permission checks on the real SDK."""

import copy
import hashlib
import json

import httpx2
import pytest
from agents.testing import ScriptedModel, assistant_message
from test_chat import settings
from test_sdk_agent import response

from repomentor.agent_tools import AgentLimits
from repomentor.cli import async_main, parser
from repomentor.config import ConfigurationError
from repomentor.finalizer_replay import prepare_replay, run_replay
from repomentor.interview_baselines import FrozenSourcesIndex
from repomentor.runtimes.openai_sdk import OpenAISdkRuntime
from repomentor.sdk_agent import SdkAgentEngine


def seeded(reader):
    content = "\n".join(reader.read("src/index.ts", 500000)[0].splitlines()[:2])
    span = {"path": "src/index.ts", "start_line": 1, "end_line": 2, "content": content,
            "content_sha256": hashlib.sha256(content.encode()).hexdigest()}
    return FrozenSourcesIndex("frozen", {"sources": [span], "retrieval": {"candidates": []}, "hits": []})


async def test_cli_replay_requires_a_declared_sealed_source_before_preparation(tmp_path):
    output = tmp_path / "unplanned"
    args = parser().parse_args(["benchmark", "prepare", "--output", str(output), "--conditions", "finalizer_candidate"])
    with pytest.raises(ConfigurationError, match="--plan"):
        await async_main(args)
    assert not output.exists()


async def test_permission_control_preserves_research_and_finalization(reader, tmp_path):
    answer = {"answer": "入口由源码支持。", "citations": [{"path": "src/index.ts", "start_line": 1, "end_line": 2}],
              "insufficient_evidence": False}
    rows, models = [], []
    for permission in (True, False):
        model = ScriptedModel([[assistant_message("已读取入口声明；整理时仍需核对源码。")],
                               [assistant_message(json.dumps(answer))]])
        runtime = OpenAISdkRuntime(settings(context_window=32768), scripted_model=model)
        row = await SdkAgentEngine(reader, seeded(reader), runtime, tmp_path / "same-cache",
            AgentLimits(max_decisions=3), tools_enabled=permission).answer("入口在哪里？")
        rows.append(row)
        models.append(model)
        assert row["completion"]["status"] == "success", row["stop_reason"]
        assert [d["phase"] for d in row["decisions"]] == ["research", "finalize"]
        assert row["new_model_requests"] == 2 and not row["cache_hit"]
        assert row["tool_calls"] == 0
        model.assert_complete()
    assert rows[0]["input"] == rows[1]["input"]
    assert rows[0]["cache_key"] != rows[1]["cache_key"]
    assert models[0].calls[0].tools and not models[1].calls[0].tools
    assert models[1].calls[0].output_schema is None
    assert models[1].calls[0].model_settings.tool_choice == "none"
    assert models[0].calls[1].input == models[1].calls[1].input


async def test_finalizer_replay_changes_only_schema_and_preserves_wire(reader, tmp_path):
    bodies = []
    def handler(request):
        bodies.append(json.loads(request.content))
        if bodies[-1]["response_format"]["json_schema"]["schema"]["properties"]["answer"]["type"] == "array":
            return response({"role": "assistant", "content": json.dumps({"answer": [{"conclusion": "入口由声明支持。", "explanation": "具体声明见已读源码。"}],
                "citations": [{"path": "src/index.ts", "start_line": 1, "end_line": 2}], "insufficient_evidence": False})})
        return response()

    async def verified():
        return {"verification": "mock-http"}

    profile = settings(context_window=32768)
    original_runtime = OpenAISdkRuntime(profile, transport=httpx2.MockTransport(handler), verifier=verified)
    original = await SdkAgentEngine(reader, seeded(reader), original_runtime, tmp_path / "cache",
                                    AgentLimits(max_tool_calls=0)).answer("入口在哪里？")
    assert original["completion"]["status"] == "success", original["stop_reason"]
    row = {"case_id": "recorded", "result": original}
    frozen = copy.deepcopy(row)
    for sectioned in (False, True):
        prepared = prepare_replay(row, original_runtime.settings, sectioned=sectioned)
        def checked(body, _):
            assert body == prepared["expected_request"]
        runtime = OpenAISdkRuntime(profile, transport=httpx2.MockTransport(handler), verifier=verified,
                                   before_dispatch=checked)
        result = await run_replay(runtime, prepared)
        assert result["completion"]["status"] == "success", result["completion"]
        assert result["new_model_requests"] == 1 and result["tool_calls"] == 0
        assert result["context"] == original["final_context"]
        assert bodies[-1]["messages"] == bodies[0]["messages"]
        assert {k: v for k, v in bodies[-1].items() if k != "response_format"} == {k: v for k, v in bodies[0].items() if k != "response_format"}
    assert bodies[0] == bodies[1]
    assert bodies[0]["response_format"] != bodies[2]["response_format"]
    assert row == frozen
